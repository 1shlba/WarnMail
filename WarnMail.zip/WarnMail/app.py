"""WarnMail launcher.

Double-clicking the packaged .exe runs this file, which opens the GUI. It is
kept small on purpose: PyInstaller uses it as the entry point, and all the
real code lives in the ``warnmail`` package.

Run from source with:  python app.py

Self-test mode (no window):

    WARNMAIL_SELFTEST=1 python app.py      # Linux/macOS
    set WARNMAIL_SELFTEST=1 && WarnMail.exe  # Windows

This loads the bundled model and analyses the built-in samples, printing a
one-line result for each. It is handy for checking that a freshly built .exe
can find its bundled files, without needing a screen.
"""

import os
import sys


def self_test() -> int:
    """Analyse every bundled sample and report. Returns an exit code."""
    from warnmail import config
    from warnmail.analyzer import Analyzer

    print(f"WarnMail {config.APP_VERSION} self-test")
    analyzer = Analyzer()
    print("model:", analyzer.model_note or "loaded OK")
    samples = sorted(config.SAMPLES_DIR.glob("*.txt"))
    if not samples:
        print("ERROR: no bundled samples found at", config.SAMPLES_DIR)
        return 1
    for path in samples:
        from warnmail.parser import read_email_file
        result = analyzer.analyze(read_email_file(path), mode="hybrid")
        print(f"  {path.name:34} -> {result.level:6} ({result.score}/100)")
    print("self-test OK")
    return 0


def main() -> int:
    if os.environ.get("WARNMAIL_SELFTEST") == "1":
        return self_test()
    from warnmail.gui import run
    run()
    return 0


if __name__ == "__main__":
    sys.exit(main())
