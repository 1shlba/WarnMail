# PyInstaller build recipe for WarnMail.
#
# Build the Windows .exe with:
#
#     pyinstaller warnmail.spec
#
# (or just run build_exe.bat, which does this and a bit more).
#
# Why a .spec file rather than a long command line? Two things need care:
#
#   1. Data files. The trained model, the sample emails and the icon are not
#      Python code, so PyInstaller will not pick them up automatically. They
#      are listed in `datas` below and are found at runtime through
#      warnmail.config.bundle_root().
#
#   2. scikit-learn's hidden imports. scikit-learn loads some pieces
#      dynamically, which a static analysis can miss, producing a .exe that
#      crashes with "ModuleNotFoundError" only once it runs. collect_submodules
#      pulls them all in.

from PyInstaller.utils.hooks import collect_submodules

hidden = (collect_submodules("sklearn")
          + collect_submodules("scipy")
          + ["joblib", "numpy"])

datas = [
    ("models/warnmail_rf.joblib", "models"),
    ("data/samples", "data/samples"),
    ("assets/warnmail.png", "assets"),
    ("assets/warnmail.ico", "assets"),
]

block_cipher = None

a = Analysis(
    ["app.py"],
    pathex=[],
    binaries=[],
    datas=datas,
    hiddenimports=hidden,
    hookspath=[],
    runtime_hooks=[],
    # Trim large libraries we don't use, so the .exe stays smaller.
    excludes=["matplotlib", "pandas", "PIL", "pytest", "tkinter.test",
              "sklearn.tests", "scipy.ndimage.tests"],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name="WarnMail",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    runtime_tmpdir=None,
    console=False,          # a GUI app: no console window
    disable_windowed_traceback=False,
    icon="assets/warnmail.ico",
)
