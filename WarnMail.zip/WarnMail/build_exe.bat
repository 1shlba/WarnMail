@echo off
REM ====================================================================
REM  Build WarnMail.exe on Windows.
REM
REM  Prerequisites (one-time):
REM    1. Install Python 3.12 (64-bit) from python.org, ticking
REM       "Add python.exe to PATH" during setup. Python 3.12 or newer is
REM       required by the versions of numpy/scipy WarnMail uses.
REM    2. Double-click this file, or run it from a command prompt.
REM
REM  It creates a virtual environment, installs the packages, makes sure a
REM  model exists, runs the tests, and builds dist\WarnMail.exe.
REM ====================================================================
setlocal

echo.
echo === WarnMail build ===
echo.

REM --- 1. Find Python -------------------------------------------------
where py >nul 2>nul
if %errorlevel%==0 (set PY=py -3.12) else (set PY=python)
%PY% --version
if %errorlevel% neq 0 (
    echo Could not find Python. Install Python 3.12 from python.org first.
    pause & exit /b 1
)

REM --- 2. Virtual environment -----------------------------------------
if not exist .venv (
    echo Creating virtual environment...
    %PY% -m venv .venv
)
call .venv\Scripts\activate.bat

REM --- 3. Dependencies ------------------------------------------------
REM  requirements.txt holds what the APP needs to run. pytest and
REM  pyinstaller are build-time tools, so they are installed here as well -
REM  otherwise the test step below fails with "No module named pytest".
echo Installing dependencies...
python -m pip install --upgrade pip >nul
python -m pip install -r requirements.txt
python -m pip install pytest==9.1.1 pyinstaller==6.22.3
if %errorlevel% neq 0 (echo Dependency install failed. & pause & exit /b 1)

REM --- 4. Make sure a trained model exists ----------------------------
if not exist models\warnmail_rf.joblib (
    echo No model found - training one now...
    python -m training.dataset
    python -m training.train_model
)

REM --- 5. Tests (optional but recommended) ----------------------------
echo Running tests...
python -m pytest -q
if %errorlevel% neq 0 (
    echo Tests failed. Fix them before shipping, or press Ctrl+C to stop.
    pause
)

REM --- 6. Build the .exe ----------------------------------------------
echo Building the executable...
pyinstaller --noconfirm --clean warnmail.spec
if %errorlevel% neq 0 (echo Build failed. & pause & exit /b 1)

REM --- 7. Check the built .exe actually works -------------------------
REM  This runs the finished .exe in self-test mode: it loads the bundled
REM  model and analyses the sample emails. It needs no Python or pytest,
REM  so it confirms the packaged app really works on its own.
echo Verifying the built app...
set WARNMAIL_SELFTEST=1
dist\WarnMail.exe
set WARNMAIL_SELFTEST=
if %errorlevel% neq 0 (echo Self-test of the built .exe FAILED. & pause & exit /b 1)

echo.
echo === Done. Your app is at dist\WarnMail.exe ===
echo.
pause
