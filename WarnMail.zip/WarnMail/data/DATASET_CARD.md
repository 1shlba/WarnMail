# WarnMail synthetic dataset

- Total emails: **144**
- Phishing: **82**  |  Legitimate: **62**
- Template groups: **12** (variants of one template share a group id)

All brands, people and domains are fictional. The data is generated from templates in `training/dataset.py` and is intended only to teach the detector the *shape* of common scams. For a real project, replace it with realistic examples you have gathered and labelled yourself.

## Why template groups matter

Variations of one template are very similar. If some land in training and others in testing, the model is effectively tested on what it already saw, and its scores look far better than they are. The training script splits by group so a whole template stays on one side. This is the single most important habit to learn with a small dataset.

## Categories

| Category | Count | Label | Note |
| --- | --- | --- | --- |
| phishing: bank-change (BEC) | 12 | phishing | hard: calm, no links |
| phishing: fake login | 16 | phishing | - |
| phishing: gift-card | 10 | phishing | - |
| phishing: malware attachment | 10 | phishing | - |
| phishing: parcel fee | 12 | phishing | - |
| phishing: prize/refund | 10 | phishing | - |
| phishing: quiet doc-share | 12 | phishing | hard: low-key phishing |
| legitimate internal note | 12 | legitimate | - |
| legitimate invoice | 16 | legitimate | - |
| legitimate newsletter | 10 | legitimate | - |
| legitimate overdue reminder | 12 | legitimate | hard: urgent but genuine |
| legitimate password reset | 12 | legitimate | hard: mentions password + link |
