"""WarnMail's desktop interface (Tkinter).

Tkinter is Python's built-in GUI toolkit, so the app needs nothing extra to
run and packages cleanly into a single .exe. The window is deliberately
simple:

    +--------------------------------------------------+
    | WarnMail            [check type: Hybrid v]       |
    | Paste an email below, or load a sample / open... |
    | +----------------------------------------------+ |
    | |  (text box - paste the email here)           | |
    | +----------------------------------------------+ |
    | [Check email] [Load sample] [Open file] [Clear] |
    | +---------------------- result ---------------+  |
    | |  HIGH RISK  score 92/100                    |  |
    | |  ...reasons, what to do, details...         |  |
    | +---------------------------------------------+  |
    +--------------------------------------------------+

The GUI contains no detection logic of its own. It calls ``Analyzer`` and
displays the ``AnalysisResult``. Keeping the two apart means everything the
GUI shows can also be produced (and tested) without a screen.
"""

from __future__ import annotations

import queue
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, font, messagebox, ttk

from warnmail import config
from warnmail.analyzer import Analyzer
from warnmail.report import AnalysisResult

# Colours for each risk level: (banner background, text colour).
LEVEL_COLOURS = {
    "High": ("#b3261e", "#ffffff"),
    "Medium": ("#b26a00", "#ffffff"),
    "Low": ("#1e7d34", "#ffffff"),
}
SEVERITY_COLOURS = {"high": "#b3261e", "medium": "#b26a00", "low": "#5f6368", "note": "#80868b"}
MODE_LABELS = {"Hybrid (recommended)": "hybrid", "Rules only": "rules", "Model only": "model"}

PLACEHOLDER = (
    "Paste a suspicious email here.\n\n"
    "Tip: include the From/Subject lines if you can - WarnMail uses them.\n"
    "Or press “Load sample” to try one of the built-in examples."
)


class WarnMailApp(ttk.Frame):
    def __init__(self, master: tk.Tk):
        super().__init__(master, padding=12)
        self.master = master
        self.grid(sticky="nsew")
        master.rowconfigure(0, weight=1)
        master.columnconfigure(0, weight=1)

        # The model can take a moment to load; do it off the main thread so the
        # window appears instantly. Until it is ready, analysis waits.
        self.analyzer: Analyzer | None = None
        self._result_queue: queue.Queue = queue.Queue()
        self._last_result: AnalysisResult | None = None
        self._showing_placeholder = True

        self._build_styles()
        self._build_widgets()
        self._load_analyzer_async()
        self.after(80, self._drain_queue)

    # -- layout --------------------------------------------------------------
    def _build_styles(self) -> None:
        self.base_font = font.nametofont("TkDefaultFont")
        self.base_font.configure(size=self.base_font.cget("size"))
        self.mono = font.Font(family="Courier", size=10)
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("Accent.TButton", font=(self.base_font.actual("family"), 10, "bold"))
        style.configure("Title.TLabel", font=(self.base_font.actual("family"), 16, "bold"))

    def _build_widgets(self) -> None:
        self.columnconfigure(0, weight=1)
        self.rowconfigure(3, weight=1)
        self.rowconfigure(5, weight=1)

        header = ttk.Frame(self)
        header.grid(row=0, column=0, sticky="ew")
        header.columnconfigure(1, weight=1)
        ttk.Label(header, text="WarnMail", style="Title.TLabel").grid(row=0, column=0, sticky="w")
        self.status = ttk.Label(header, text="Loading model…", foreground="#5f6368")
        self.status.grid(row=0, column=1, sticky="w", padx=12)

        ttk.Label(header, text="Check type:").grid(row=0, column=2, padx=(0, 6))
        self.mode_var = tk.StringVar(value="Hybrid (recommended)")
        mode_box = ttk.Combobox(header, textvariable=self.mode_var, state="readonly",
                                width=20, values=list(MODE_LABELS))
        mode_box.grid(row=0, column=3, sticky="e")
        mode_box.bind("<<ComboboxSelected>>", lambda _e: self._reanalyse_if_possible())

        ttk.Label(self, text="Paste an email below, then press “Check email”.")\
            .grid(row=1, column=0, sticky="w", pady=(10, 4))

        # Input text box.
        in_frame = ttk.Frame(self)
        in_frame.grid(row=3, column=0, sticky="nsew")
        in_frame.rowconfigure(0, weight=1)
        in_frame.columnconfigure(0, weight=1)
        self.input = tk.Text(in_frame, wrap="word", height=12, undo=True,
                             font=(self.base_font.actual("family"), 10))
        self.input.grid(row=0, column=0, sticky="nsew")
        in_scroll = ttk.Scrollbar(in_frame, command=self.input.yview)
        in_scroll.grid(row=0, column=1, sticky="ns")
        self.input.configure(yscrollcommand=in_scroll.set)
        self._set_placeholder()
        self.input.bind("<FocusIn>", self._clear_placeholder)
        self.input.bind("<FocusOut>", self._maybe_restore_placeholder)

        # Buttons.
        buttons = ttk.Frame(self)
        buttons.grid(row=4, column=0, sticky="ew", pady=8)
        self.check_btn = ttk.Button(buttons, text="Check email", style="Accent.TButton",
                                    command=self.check_email)
        self.check_btn.pack(side="left")
        ttk.Button(buttons, text="Load sample", command=self.load_sample).pack(side="left", padx=6)
        ttk.Button(buttons, text="Open file…", command=self.open_file).pack(side="left")
        ttk.Button(buttons, text="Clear", command=self.clear_input).pack(side="left", padx=6)
        self.copy_btn = ttk.Button(buttons, text="Copy report", command=self.copy_report,
                                   state="disabled")
        self.copy_btn.pack(side="right")
        self.save_btn = ttk.Button(buttons, text="Save report…", command=self.save_report,
                                   state="disabled")
        self.save_btn.pack(side="right", padx=6)

        # Result area: coloured banner + scrolling detail.
        self.banner = tk.Label(self, text="", anchor="w", padx=12, pady=10,
                               font=(self.base_font.actual("family"), 13, "bold"))
        self.banner.grid(row=5, column=0, sticky="new")
        self.banner.grid_remove()

        out_frame = ttk.Frame(self)
        out_frame.grid(row=6, column=0, sticky="nsew", pady=(6, 0))
        self.rowconfigure(6, weight=2)
        out_frame.rowconfigure(0, weight=1)
        out_frame.columnconfigure(0, weight=1)
        self.output = tk.Text(out_frame, wrap="word", height=12, state="disabled",
                              font=(self.base_font.actual("family"), 10),
                              background="#f7f7f8", relief="flat", padx=10, pady=8)
        self.output.grid(row=0, column=0, sticky="nsew")
        out_scroll = ttk.Scrollbar(out_frame, command=self.output.yview)
        out_scroll.grid(row=0, column=1, sticky="ns")
        self.output.configure(yscrollcommand=out_scroll.set)
        self._configure_tags()

        self.master.bind("<Control-Return>", lambda _e: self.check_email())

    def _configure_tags(self) -> None:
        fam = self.base_font.actual("family")
        self.output.tag_configure("h", font=(fam, 11, "bold"), spacing1=8, spacing3=4)
        self.output.tag_configure("summary", font=(fam, 11), spacing3=8)
        self.output.tag_configure("high", foreground=SEVERITY_COLOURS["high"], font=(fam, 10, "bold"))
        self.output.tag_configure("medium", foreground=SEVERITY_COLOURS["medium"], font=(fam, 10, "bold"))
        self.output.tag_configure("low", foreground=SEVERITY_COLOURS["low"], font=(fam, 10, "bold"))
        self.output.tag_configure("note", foreground=SEVERITY_COLOURS["note"], font=(fam, 10, "italic"))
        self.output.tag_configure("detail", lmargin1=20, lmargin2=20, spacing3=2)
        self.output.tag_configure("evidence", lmargin1=36, lmargin2=50, foreground="#444")
        self.output.tag_configure("muted", foreground="#5f6368")
        self.output.tag_configure("advice", font=(fam, 10), lmargin1=12, lmargin2=12, spacing1=2)

    # -- placeholder handling ------------------------------------------------
    def _set_placeholder(self) -> None:
        self.input.delete("1.0", "end")
        self.input.insert("1.0", PLACEHOLDER)
        self.input.configure(foreground="#9aa0a6")
        self._showing_placeholder = True

    def _clear_placeholder(self, _event=None) -> None:
        if self._showing_placeholder:
            self.input.delete("1.0", "end")
            self.input.configure(foreground="black")
            self._showing_placeholder = False

    def _maybe_restore_placeholder(self, _event=None) -> None:
        if not self.input.get("1.0", "end").strip():
            self._set_placeholder()

    def _current_text(self) -> str:
        return "" if self._showing_placeholder else self.input.get("1.0", "end").strip()

    # -- model loading (background thread) -----------------------------------
    def _load_analyzer_async(self) -> None:
        def worker():
            try:
                analyzer = Analyzer()
                self._result_queue.put(("ready", analyzer))
            except Exception as exc:  # pragma: no cover - defensive
                self._result_queue.put(("load_error", exc))
        threading.Thread(target=worker, daemon=True).start()

    def _drain_queue(self) -> None:
        try:
            while True:
                kind, payload = self._result_queue.get_nowait()
                if kind == "ready":
                    self.analyzer = payload
                    if payload.model_note:
                        self.status.configure(text="Ready (rules only - no model loaded)",
                                              foreground="#b26a00")
                    else:
                        self.status.configure(text="Ready", foreground="#1e7d34")
                elif kind == "load_error":
                    self.status.configure(text="Could not start", foreground="#b3261e")
                    messagebox.showerror("WarnMail", f"Could not start:\n{payload}")
                elif kind == "result":
                    self._show_result(payload)
                elif kind == "analyse_error":
                    self.check_btn.configure(state="normal")
                    messagebox.showerror("WarnMail", f"Could not analyse the email:\n{payload}")
        except queue.Empty:
            pass
        self.after(80, self._drain_queue)

    # -- actions -------------------------------------------------------------
    def check_email(self) -> None:
        if self.analyzer is None:
            messagebox.showinfo("WarnMail", "Still loading the model - try again in a moment.")
            return
        text = self._current_text()
        if not text:
            messagebox.showinfo("WarnMail", "Paste an email first, or press “Load sample”.")
            return
        mode = MODE_LABELS[self.mode_var.get()]
        self.check_btn.configure(state="disabled")
        self.status.configure(text="Checking…", foreground="#5f6368")

        def worker():
            try:
                result = self.analyzer.analyze(text, mode=mode)
                self._result_queue.put(("result", result))
            except Exception as exc:
                self._result_queue.put(("analyse_error", exc))
        threading.Thread(target=worker, daemon=True).start()

    def _reanalyse_if_possible(self) -> None:
        if self._last_result is not None and self._current_text():
            self.check_email()

    def load_sample(self) -> None:
        samples = sorted(config.SAMPLES_DIR.glob("*.txt"))
        if not samples:
            messagebox.showinfo("WarnMail", "No sample emails were bundled with this copy.")
            return
        SamplePicker(self, samples, self._use_sample_text)

    def _use_sample_text(self, text: str) -> None:
        self._clear_placeholder()
        self.input.delete("1.0", "end")
        self.input.insert("1.0", text)
        self.input.configure(foreground="black")
        self._showing_placeholder = False
        self.check_email()

    def open_file(self) -> None:
        path = filedialog.askopenfilename(
            title="Open an email",
            filetypes=[("Email or text", "*.eml *.txt *.msg"), ("All files", "*.*")])
        if not path:
            return
        try:
            from warnmail.parser import read_email_file
            self._use_sample_text(read_email_file(path))
        except Exception as exc:
            messagebox.showerror("WarnMail", f"Could not read that file:\n{exc}")

    def clear_input(self) -> None:
        self.input.delete("1.0", "end")
        self.input.focus_set()
        self._showing_placeholder = False
        self._maybe_restore_placeholder()

    def copy_report(self) -> None:
        if self._last_result:
            self.master.clipboard_clear()
            self.master.clipboard_append(self._last_result.to_text())
            self.status.configure(text="Report copied to clipboard", foreground="#1e7d34")

    def save_report(self) -> None:
        if not self._last_result:
            return
        path = filedialog.asksaveasfilename(
            title="Save report", defaultextension=".txt",
            initialfile="warnmail_report.txt", filetypes=[("Text file", "*.txt")])
        if path:
            Path(path).write_text(self._last_result.to_text(), encoding="utf-8")
            self.status.configure(text=f"Saved to {Path(path).name}", foreground="#1e7d34")

    # -- rendering the result ------------------------------------------------
    def _show_result(self, result: AnalysisResult) -> None:
        self._last_result = result
        self.check_btn.configure(state="normal")
        self.save_btn.configure(state="normal")
        self.copy_btn.configure(state="normal")
        self.status.configure(text="Ready", foreground="#1e7d34")

        bg, fg = LEVEL_COLOURS[result.level]
        self.banner.configure(text=f"   {result.level.upper()} RISK      score {result.score}/100",
                              background=bg, foreground=fg)
        self.banner.grid()

        self.output.configure(state="normal")
        self.output.delete("1.0", "end")
        self._insert(result.summary + "\n", "summary")

        if result.findings:
            self._insert("Warning signs\n", "h")
            for finding in result.findings:
                self._insert(f"[{finding.severity.upper()}] ", finding.severity)
                self._insert(f"{finding.title}\n", finding.severity)
                self._insert(finding.detail + "\n", "detail")
                for item in finding.evidence:
                    self._insert(f"• {item}\n", "evidence")
        elif result.mode != "model":
            self._insert("Warning signs\n", "h")
            self._insert("None of WarnMail's rules matched this email.\n", "detail")

        if result.model.available:
            self._insert("\nMachine-learning model\n", "h")
            self._insert(f"Rates this {result.model.percent}% likely to be phishing.\n", "detail")
            for reason in result.model.reasons:
                self._insert(f"• {reason}\n", "evidence")
        elif result.model.note and result.mode in ("hybrid", "model"):
            self._insert("\nMachine-learning model\n", "h")
            self._insert(result.model.note + "\n", "muted")

        if result.overrides:
            self._insert("\nAdjustments\n", "h")
            for item in result.overrides:
                self._insert(f"• {item}\n", "evidence")

        self._insert("\nWhat to do\n", "h")
        self._insert(result.advice + "\n", "advice")
        self._insert("\nWarnMail is a learning prototype, not a security guarantee. "
                     "Always use your own judgement.\n", "muted")
        self.output.configure(state="disabled")

    def _insert(self, text: str, tag: str) -> None:
        self.output.insert("end", text, tag)


class SamplePicker(tk.Toplevel):
    """A small window listing the bundled sample emails."""

    def __init__(self, app: WarnMailApp, samples: list[Path], on_choose):
        super().__init__(app.master)
        self.title("Load a sample email")
        self.on_choose = on_choose
        self.samples = samples
        self.resizable(False, False)
        self.transient(app.master)

        ttk.Label(self, text="Choose a sample to analyse:", padding=10).grid(row=0, column=0, sticky="w")
        listbox = tk.Listbox(self, width=44, height=min(10, len(samples)))
        listbox.grid(row=1, column=0, padx=10, sticky="ew")
        for path in samples:
            listbox.insert("end", self._pretty(path.name))
        listbox.selection_set(0)
        listbox.bind("<Double-Button-1>", lambda _e: self._choose(listbox))

        buttons = ttk.Frame(self, padding=10)
        buttons.grid(row=2, column=0, sticky="e")
        ttk.Button(buttons, text="Cancel", command=self.destroy).pack(side="right", padx=4)
        ttk.Button(buttons, text="Load", style="Accent.TButton",
                   command=lambda: self._choose(listbox)).pack(side="right")
        self.listbox = listbox
        self.grab_set()

    @staticmethod
    def _pretty(name: str) -> str:
        stem = Path(name).stem
        parts = stem.split("_", 1)
        label = parts[1] if len(parts) == 2 and parts[0].isdigit() else stem
        return label.replace("_", " ")

    def _choose(self, listbox: tk.Listbox) -> None:
        selection = listbox.curselection()
        if not selection:
            return
        path = self.samples[selection[0]]
        try:
            from warnmail.parser import read_email_file
            text = read_email_file(path)
        except Exception as exc:
            messagebox.showerror("WarnMail", f"Could not read the sample:\n{exc}")
            return
        self.destroy()
        self.on_choose(text)


def run() -> None:
    root = tk.Tk()
    root.title(f"{config.APP_NAME} {config.APP_VERSION} - phishing email checker")
    root.geometry("860x760")
    root.minsize(640, 600)
    _set_window_icon(root)
    WarnMailApp(root)
    root.mainloop()


def _set_window_icon(root: tk.Tk) -> None:
    for name in ("warnmail.png", "warnmail.gif"):
        icon_path = config.ASSETS_DIR / name
        if icon_path.exists():
            try:
                root.iconphoto(True, tk.PhotoImage(file=str(icon_path)))
                return
            except tk.TclError:
                continue


if __name__ == "__main__":
    run()
