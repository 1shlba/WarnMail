"""The rule engine: human-readable warning signs with a points score.

Each rule is a small function that looks at the detected ``Signals`` and
either returns a ``Finding`` or ``None``. A finding has a severity:

* high   - a strong, specific sign of phishing (disguised link, gift cards)
* medium - a common phishing tactic that also appears in some genuine email
* low    - a weak hint on its own

Points per severity come from ``config.SEVERITY_POINTS``. The rule score is
the total, capped at 100.

To add a rule: write a function that takes ``Signals`` and returns a
``Finding`` or ``None``, then add it to ``RULES`` at the bottom.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from warnmail import config
from warnmail.signals import Signals

SEVERITY_ORDER = {"high": 0, "medium": 1, "low": 2, "note": 3}


@dataclass
class Finding:
    rule_id: str
    severity: str           # "high", "medium" or "low"
    title: str              # short headline shown to the user
    detail: str             # one or two plain-language sentences
    evidence: list[str] = field(default_factory=list)

    @property
    def points(self) -> int:
        return config.SEVERITY_POINTS[self.severity]


@dataclass
class RuleResult:
    findings: list[Finding]
    score: int

    @property
    def high_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == "high")


def _quote(items, limit: int = 4) -> list[str]:
    return [f"“{item}”" for item in list(items)[:limit]]


# ---------------------------------------------------------------------------
# Content rules
# ---------------------------------------------------------------------------

def rule_pressure(s: Signals) -> Finding | None:
    urgency, threat = s.phrases["urgency"], s.phrases["threat"]
    if not (urgency or threat):
        return None
    severity = "medium" if urgency and threat else "low"
    return Finding(
        "pressure", severity, "Pressure to act quickly",
        "Scammers rush you with deadlines or threats so you act before thinking."
        if severity == "medium" else
        "The email uses urgent or threatening wording. On its own this is common, "
        "but be careful if it also asks you to do something.",
        _quote(urgency + threat))


def rule_credentials(s: Signals) -> Finding | None:
    phrases = s.phrases["credential"]
    if not phrases:
        return None
    if s.offsite_links or s.risky_links:
        return Finding(
            "credentials", "high", "Asks you to sign in through a link",
            "It talks about passwords, sign-ins or codes and gives you a link to another "
            "website. Genuine organisations rarely ask you to sign in from an email link.",
            _quote(phrases))
    if s.links:
        return Finding(
            "credentials", "medium", "Asks you to sign in or verify details",
            "It asks about passwords, sign-ins or codes. Even if the link looks right, it "
            "is safer to type the website address yourself.",
            _quote(phrases))
    return Finding(
        "credentials", "low", "Mentions passwords or security codes",
        "Never share a password or code by email or phone, even with someone who "
        "says they are from IT or your bank.",
        _quote(phrases))


def rule_payment_pressure(s: Signals) -> Finding | None:
    payment = s.phrases["payment"]
    if payment and (s.phrases["urgency"] or s.phrases["threat"]):
        return Finding(
            "payment_pressure", "medium", "Pushes for a payment under time pressure",
            "Requests to pay quickly are a favourite scam tactic. Check the invoice and the "
            "payee with someone you trust before paying.",
            _quote(payment))
    return None


def rule_bank_change(s: Signals) -> Finding | None:
    phrases = s.phrases["bank_change"]
    if not phrases:
        return None
    return Finding(
        "bank_change", "high", "Says bank details have changed",
        "Changed bank details is the most common business email scam. Always confirm by "
        "phone, using a number you already have, before paying a new account.",
        _quote(phrases))


def rule_gift_cards(s: Signals) -> Finding | None:
    phrases = s.phrases["gift_card"]
    if not phrases:
        return None
    return Finding(
        "gift_cards", "high", "Asks about gift cards",
        "Real managers and organisations do not ask staff to buy gift cards and send the "
        "codes. This is a very common scam.",
        _quote(phrases))


def rule_secrecy(s: Signals) -> Finding | None:
    phrases = s.phrases["secrecy"]
    if not phrases:
        return None
    return Finding(
        "secrecy", "medium", "Asks for secrecy or avoids a phone call",
        "Scammers pretending to be a boss or client often say they cannot talk and ask you "
        "to keep the request quiet, so nobody checks it.",
        _quote(phrases))


def rule_sensitive_info(s: Signals) -> Finding | None:
    phrases = s.phrases["sensitive_info"]
    if not phrases:
        return None
    severity = "high" if (s.offsite_links or s.risky_links) else "medium"
    return Finding(
        "sensitive_info", severity, "Asks for personal, tax or card details",
        "Be very careful with any email asking for things like your tax file number, card "
        "details or licence. Give them only through a channel you trust.",
        _quote(phrases))


def rule_reward(s: Signals) -> Finding | None:
    phrases = s.phrases["reward"]
    if not phrases:
        return None
    severity = "medium" if len(phrases) >= 2 or s.risky_links else "low"
    return Finding(
        "reward", severity, "Offers a prize, refund or reward",
        "Unexpected prizes, refunds and vouchers are a common lure to get you to click.",
        _quote(phrases))


def rule_generic_greeting(s: Signals) -> Finding | None:
    if not s.generic_greeting:
        return None
    return Finding(
        "generic_greeting", "low", "Generic greeting",
        "It does not use your name. Organisations you deal with usually know who you are.",
        _quote([s.generic_greeting]))


def rule_shouting(s: Signals) -> Finding | None:
    if s.exclamations >= 3 or s.shouting_ratio >= 0.1:
        return Finding(
            "shouting", "low", "Lots of capitals or exclamation marks",
            "Heavy use of capitals and exclamation marks is used to create alarm or excitement.")
    return None


# ---------------------------------------------------------------------------
# Link rules
# ---------------------------------------------------------------------------

def rule_disguised_links(s: Signals) -> Finding | None:
    links = [l for l in s.links if l.shown_domain]
    if not links:
        return None
    return Finding(
        "disguised_link", "high", "A link is disguised",
        "The link text shows one website, but clicking it would take you somewhere else.",
        [f"shows {l.shown_domain} but goes to {l.host}" for l in links[:4]])


def rule_ip_links(s: Signals) -> Finding | None:
    links = [l for l in s.links if l.is_ip]
    if not links:
        return None
    return Finding(
        "ip_link", "high", "A link goes to a bare number address",
        "Genuine websites use names, not raw IP addresses. Scam sites often skip the name.",
        [l.host for l in links[:4]])


def rule_shortened_links(s: Signals) -> Finding | None:
    links = [l for l in s.links if l.is_shortener]
    if not links:
        return None
    return Finding(
        "short_link", "medium", "A shortened link hides where it goes",
        "Link shorteners hide the real destination, so you cannot check it before clicking.",
        [l.url for l in links[:4]])


def rule_risky_tld(s: Signals) -> Finding | None:
    links = [l for l in s.links if l.risky_tld]
    if not links:
        return None
    return Finding(
        "risky_tld", "medium", "A link uses an unusual web address ending",
        "Endings such as .top, .xyz or .click are cheap and heavily used by scam sites.",
        [l.host for l in links[:4]])


def rule_deceptive_links(s: Signals) -> Finding | None:
    """Genuine link-disguise tricks (an @-sign hiding the host, or punycode)."""
    links = [l for l in s.links if l.deceptive]
    if not links:
        return None
    return Finding(
        "deceptive_link", "medium", "A link is built to disguise its real address",
        "The address uses a trick - an @ sign that hides the true host, or look-alike "
        "foreign characters - to make a link appear to go somewhere you trust.",
        [f"{l.host}: {l.deceptive[0]}" for l in links[:4]])


def rule_unusual_links(s: Signals) -> Finding | None:
    """Weak, cosmetic oddities: long, hyphenated or deeply nested addresses.

    Deliberately scored as a "note" worth only a couple of points. Plenty of
    genuine links are long or hyphenated, so this is a consideration to show
    the user, not real evidence of phishing.
    """
    links = [l for l in s.links if l.unusual]
    if not links:
        return None
    return Finding(
        "unusual_link", "note", "A link has an unusual structure",
        "Minor note only: a link is long, heavily hyphenated or deeply nested. On its "
        "own this is weak - many genuine links look like this - so it barely affects "
        "the score.",
        [f"{l.host}: {l.unusual[0]}" for l in links[:4]])


def rule_insecure_login(s: Signals) -> Finding | None:
    links = [l for l in s.links if l.insecure and l.login_words and not l.is_ip]
    if not links:
        return None
    return Finding(
        "insecure_login", "medium", "A sign-in style link is not secure",
        "The link starts with http:// rather than https:// yet looks like a sign-in or "
        "verification page.",
        [l.host for l in links[:4]])


def rule_lookalikes(s: Signals) -> Finding | None:
    if not s.lookalikes:
        return None
    return Finding(
        "lookalike", "high", "Imitates a known organisation",
        "A web or email address closely imitates a trusted name but is not its real address.",
        s.lookalikes[:4])


# ---------------------------------------------------------------------------
# Sender rules
# ---------------------------------------------------------------------------

def rule_display_mismatch(s: Signals) -> Finding | None:
    if not s.sender.display_mismatch:
        return None
    return Finding(
        "display_mismatch", "high", "The sender's name doesn't match the address",
        s.sender.display_mismatch, [s.sender.address])


def rule_reply_to(s: Signals) -> Finding | None:
    if not s.sender.reply_to:
        return None
    severity = "high" if s.sender.reply_to_risky else "medium"
    return Finding(
        "reply_to", severity, "Replies would go to someone else",
        f"If you reply, your answer goes to {s.sender.reply_to}, not to the address the "
        "email came from. Scammers use this to receive your reply.",
        [s.sender.reply_to])


def rule_free_webmail(s: Signals) -> Finding | None:
    if not s.sender.free_webmail_business_name:
        return None
    return Finding(
        "free_webmail", "medium", "Official-sounding name on a free email account",
        f"It is signed '{s.sender.display_name}' but was sent from a free account "
        f"({s.sender.domain}). Organisations and managers normally use their own domain.",
        [s.sender.address])


# ---------------------------------------------------------------------------
# Attachment rule
# ---------------------------------------------------------------------------

def rule_attachments(s: Signals) -> Finding | None:
    risky = [a for a in s.attachments if a.risk]
    if not risky:
        return None
    severity = "high" if any(a.risk == "high" for a in risky) else "medium"
    return Finding(
        "attachment", severity, "Risky attachment",
        "Do not open it. " + risky[0].reason[0].upper() + risky[0].reason[1:] + ".",
        [a.name for a in risky[:4]])


RULES = (
    rule_disguised_links, rule_lookalikes, rule_display_mismatch, rule_gift_cards,
    rule_bank_change, rule_attachments, rule_ip_links, rule_deceptive_links,
    rule_credentials, rule_sensitive_info, rule_reply_to, rule_free_webmail,
    rule_secrecy, rule_payment_pressure, rule_shortened_links, rule_risky_tld,
    rule_insecure_login, rule_pressure, rule_reward, rule_generic_greeting,
    rule_shouting, rule_unusual_links,
)


def evaluate_rules(signals: Signals) -> RuleResult:
    findings = [finding for rule in RULES if (finding := rule(signals)) is not None]
    findings.sort(key=lambda f: SEVERITY_ORDER[f.severity])
    score = min(config.MAX_RULE_SCORE, sum(f.points for f in findings))
    return RuleResult(findings=findings, score=score)
