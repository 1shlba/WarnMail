"""Turn detected signals into the numbers the Random Forest learns from.

A Random Forest cannot read text. It needs every email described by the same
list of numbers, in the same order, every time. ``FEATURES`` defines that
list. Two rules keep this safe:

1. The order of ``FEATURES`` is the contract between training and
   prediction. The trained model file stores the feature names it was
   trained with, and ``model.py`` refuses to predict if they differ.
   (Feeding features in a different order is a classic silent bug: the
   model still returns an answer, just a meaningless one.)
2. Every feature must be computable for *every* email, including one with
   no links, no sender and no subject. Ratios therefore go through
   ``safe_ratio`` so an email without links gives 0, not a crash.
"""

from __future__ import annotations

from warnmail.signals import Signals

# (feature name, plain-English description). The order matters - see above.
FEATURES: tuple[tuple[str, str], ...] = (
    ("urgency_phrases", "Urgent or time-pressure phrases"),
    ("threat_phrases", "Threats or consequences (suspended, locked, legal action...)"),
    ("credential_phrases", "Mentions of passwords, sign-ins or verification codes"),
    ("payment_phrases", "Mentions of invoices, payments or bank accounts"),
    ("bank_change_phrases", "Claims that bank details have changed"),
    ("secrecy_phrases", "Requests for secrecy or to avoid phone calls"),
    ("gift_card_phrases", "Gift-card related phrases"),
    ("sensitive_info_phrases", "Requests for personal, tax or card details"),
    ("reward_phrases", "Prize, refund or reward phrases"),
    ("click_phrases", "'Click here' / 'open the attachment' style instructions"),
    ("generic_greeting", "Opens with a generic greeting such as 'Dear Customer' (1 = yes)"),
    ("subject_alarm_words", "Alarming words in the subject line"),
    ("exclamation_marks", "Exclamation marks (capped at 10)"),
    ("shouting_ratio", "Share of words written in CAPITALS"),
    ("body_words", "Length of the body in words"),
    ("link_count", "Number of links"),
    ("offsite_link_ratio", "Share of links going to a different site from the sender's"),
    ("ip_links", "Links pointing at a raw IP address"),
    ("shortened_links", "Links using a URL shortener"),
    ("risky_tld_links", "Links with a commonly abused ending (.top, .xyz, .click...)"),
    ("disguised_links", "Links whose visible text shows a different website"),
    ("insecure_links", "Links using http:// rather than https://"),
    ("login_word_links", "Links containing words like login, verify or secure"),
    ("unusual_links", "Links with an odd structure (@ trick, punycode, many sub-domains)"),
    ("lookalike_domains", "Sender or link domains imitating a known organisation"),
    ("has_sender", "The sender's address is known (1 = yes)"),
    ("display_name_mismatch", "Sender's name and address disagree (1 = yes)"),
    ("reply_to_mismatch", "Replies would go to a different domain (1 = yes)"),
    ("free_webmail_official_name", "Official-sounding name on a free email account (1 = yes)"),
    ("attachment_count", "Number of attachments"),
    ("risky_attachments", "Attachments of a dangerous type"),
)

FEATURE_NAMES: list[str] = [name for name, _ in FEATURES]
FEATURE_DESCRIPTIONS: dict[str, str] = dict(FEATURES)


def safe_ratio(part: float, whole: float) -> float:
    """part / whole, but 0.0 when whole is 0 (e.g. an email with no links)."""
    return part / whole if whole else 0.0


def extract_features(signals: Signals) -> dict[str, float]:
    """Describe one email as a dict of numbers, in ``FEATURE_NAMES`` order."""
    p = signals.phrases
    links = signals.links
    sender = signals.sender

    def count_links(condition) -> int:
        return sum(1 for link in links if condition(link))

    values = {
        "urgency_phrases": len(p["urgency"]),
        "threat_phrases": len(p["threat"]),
        "credential_phrases": len(p["credential"]),
        "payment_phrases": len(p["payment"]),
        "bank_change_phrases": len(p["bank_change"]),
        "secrecy_phrases": len(p["secrecy"]),
        "gift_card_phrases": len(p["gift_card"]),
        "sensitive_info_phrases": len(p["sensitive_info"]),
        "reward_phrases": len(p["reward"]),
        "click_phrases": len(p["click"]),
        "generic_greeting": int(signals.generic_greeting is not None),
        "subject_alarm_words": len(signals.subject_alarm),
        "exclamation_marks": signals.exclamations,
        "shouting_ratio": signals.shouting_ratio,
        "body_words": signals.body_words,
        "link_count": len(links),
        "offsite_link_ratio": round(safe_ratio(count_links(lambda l: l.external), len(links)), 4),
        "ip_links": count_links(lambda l: l.is_ip),
        "shortened_links": count_links(lambda l: l.is_shortener),
        "risky_tld_links": count_links(lambda l: bool(l.risky_tld)),
        "disguised_links": count_links(lambda l: bool(l.shown_domain)),
        "insecure_links": count_links(lambda l: l.insecure),
        "login_word_links": count_links(lambda l: bool(l.login_words)),
        # Count both the genuine deception tricks and the cosmetic oddities, so
        # this feature's value is unchanged by the rules-side split (no retrain
        # needed). The rules weight the two groups very differently; the model
        # is free to learn their combined usefulness.
        "unusual_links": count_links(lambda l: bool(l.unusual or l.deceptive)),
        "lookalike_domains": len(signals.lookalikes),
        "has_sender": int(sender.has_sender),
        "display_name_mismatch": int(bool(sender.display_mismatch)),
        "reply_to_mismatch": int(bool(sender.reply_to)),
        "free_webmail_official_name": int(sender.free_webmail_business_name),
        "attachment_count": len(signals.attachments),
        "risky_attachments": sum(1 for a in signals.attachments if a.risk),
    }
    # Guard against someone adding a feature here but not to FEATURES.
    if list(values) != FEATURE_NAMES:
        raise RuntimeError("extract_features() and FEATURES are out of sync")
    return {name: float(value) for name, value in values.items()}


def to_vector(features: dict[str, float], names: list[str] | None = None) -> list[float]:
    """Order a feature dict as a plain list, following ``names``."""
    return [float(features[name]) for name in (names or FEATURE_NAMES)]
