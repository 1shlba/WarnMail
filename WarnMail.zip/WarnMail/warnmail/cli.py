"""Command-line interface: analyse an email without opening the GUI.

Examples::

    python -m warnmail.cli data/samples/01_phishing_bank_login.txt
    python -m warnmail.cli --mode rules email.eml
    echo "...pasted email..." | python -m warnmail.cli -

Useful for quick checks, for scripting, and for seeing the exact same result
the GUI shows (both call the same ``Analyzer``).
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from warnmail.analyzer import Analyzer


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Check an email for phishing signs with WarnMail.")
    parser.add_argument("source", help="path to a .txt/.eml file, or - to read from standard input")
    parser.add_argument("--mode", choices=["hybrid", "rules", "model"], default="hybrid",
                        help="which check to use (default: hybrid)")
    parser.add_argument("--model", type=Path, default=None, help="path to a model bundle")
    args = parser.parse_args(argv)

    if args.source == "-":
        text = sys.stdin.read()
    else:
        path = Path(args.source)
        if not path.exists():
            print(f"File not found: {path}", file=sys.stderr)
            return 2
        from warnmail.parser import read_email_file
        text = read_email_file(path)

    analyzer = Analyzer(model_path=args.model)
    result = analyzer.analyze(text, mode=args.mode)
    print(result.to_text())
    # Exit code: 0 = Low, 1 = Medium, 2 = High. Handy in scripts.
    return {"Low": 0, "Medium": 1, "High": 2}[result.level]


if __name__ == "__main__":
    raise SystemExit(main())
