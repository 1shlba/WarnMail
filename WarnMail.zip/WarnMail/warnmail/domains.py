"""Domain-name helpers and reference lists.

Phishing emails very often give themselves away through the *domains* they
use: a sender address on a free webmail service while claiming to be a bank,
a link to ``harbourline-secure.top`` instead of ``harbourlinebank.com.au``, a
link that points at a raw IP address, and so on. This module holds the lists
and small functions needed to spot those patterns.

All brand names in ``KNOWN_BRANDS`` are fictional and only exist for this
learning project. In a real deployment you would list the organisations your
users actually deal with (their bank, courier, accounting software...).
"""

from __future__ import annotations

import ipaddress
from dataclasses import dataclass
from typing import Iterable

# Two-part public suffixes, so that "mail.harbourlinebank.com.au" reduces to
# "harbourlinebank.com.au" rather than "com.au". A full solution would use the
# Public Suffix List (e.g. the ``tldextract`` package); this short list keeps
# the app dependency-free and covers the domains used in this project.
MULTI_PART_SUFFIXES = {
    "com.au", "net.au", "org.au", "edu.au", "gov.au", "asn.au", "id.au",
    "co.uk", "org.uk", "ac.uk", "gov.uk", "co.nz", "net.nz", "org.nz",
    "govt.nz", "com.sg", "com.my", "co.in", "co.jp", "com.br", "co.za",
}

FREE_WEBMAIL_DOMAINS = {
    "gmail.com", "googlemail.com", "outlook.com", "hotmail.com", "live.com",
    "msn.com", "yahoo.com", "yahoo.com.au", "icloud.com", "me.com", "aol.com",
    "proton.me", "protonmail.com", "gmx.com", "mail.com", "zoho.com",
    "bigpond.com", "bigpond.net.au", "optusnet.com.au", "iinet.net.au",
    "tpg.com.au", "internode.on.net",
}

# Corporate / service domains whose automated notifications are normally safe
# (a Google Docs share, a GitHub notification, a DocuSign request...). These are
# the ORGANISATIONS' real domains, NOT consumer webmail: gmail.com, outlook.com,
# icloud.com and the like are deliberately left out, because anyone can open a
# personal account there, so "from gmail.com" means nothing about trust.
#
# IMPORTANT: this matches the *From* domain, which can be forged. WarnMail uses
# it only as one input, gated by other checks (see analyzer._trusted_source).
# Real trust needs SPF/DKIM/DMARC verification, which needs the full headers.
TRUSTED_DOMAINS = {
    "google.com", "googlemail.com", "youtube.com", "gstatic.com",
    "microsoft.com", "microsoftonline.com", "office.com", "office365.com",
    "sharepoint.com", "azure.com", "apple.com", "anthropic.com", "claude.ai",
    "github.com", "githubusercontent.com", "atlassian.com", "atlassian.net",
    "slack.com", "dropbox.com", "dropboxmail.com", "zoom.us", "docusign.net",
    "docusign.com", "notion.so", "linkedin.com", "amazon.com", "amazonses.com",
    "adobe.com", "canva.com", "figma.com", "xero.com", "myob.com", "intuit.com",
    "stripe.com", "paypal.com.au", "auspost.com.au", "mygov.au", "ato.gov.au",
}

URL_SHORTENERS = {
    "bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd", "buff.ly",
    "rebrand.ly", "cutt.ly", "shorturl.at", "rb.gy", "t.ly", "tiny.cc",
    "s.id", "v.gd", "lnkd.in",
}

# Top-level domains that are cheap to register and heavily abused in phishing
# campaigns. Legitimate sites do use some of them, so this is a warning sign,
# not proof.
RISKY_TLDS = {
    "top", "xyz", "click", "link", "live", "icu", "buzz", "rest", "country",
    "gq", "tk", "ml", "cf", "ga", "work", "support", "zip", "mov", "cam",
    "quest", "sbs", "cfd", "monster", "lol", "bond", "online", "site",
}

# Words that phishing kits like to put in their URLs.
LOGIN_URL_WORDS = (
    "login", "log-in", "signin", "sign-in", "verify", "verification",
    "secure", "security", "account", "update", "confirm", "password",
    "auth", "validate", "unlock", "webscr", "billing", "wallet", "reset",
)


@dataclass(frozen=True)
class Brand:
    """An organisation users trust, and the domains it really uses."""

    name: str                     # how we describe it to the user
    token: str                    # distinctive word we look for in domains
    domains: tuple[str, ...]      # its genuine registered domains


# Fictional organisations used throughout the synthetic dataset.
KNOWN_BRANDS: tuple[Brand, ...] = (
    Brand("Harbourline Bank", "harbourline", ("harbourlinebank.com.au",)),
    Brand("WorkHub 365", "workhub", ("workhub365.com",)),
    Brand("CloudNest", "cloudnest", ("cloudnest.com",)),
    Brand("SwiftParcel", "swiftparcel", ("swiftparcel.com.au",)),
    Brand("Ledgerly", "ledgerly", ("ledgerly.com",)),
    Brand("PayRoo", "payroo", ("payroo.com.au",)),
    Brand("Gumleaf Energy", "gumleaf", ("gumleafenergy.com.au",)),
    Brand("SignFlow", "signflow", ("signflow.com",)),
    Brand("BrightMart", "brightmart", ("brightmart.com.au",)),
    Brand("Linkway", "linkway", ("linkway.com.au",)),
    Brand("TaxPoint", "taxpoint", ("taxpoint.com.au",)),
    Brand("DomainHaven", "domainhaven", ("domainhaven.com.au",)),
)


def host_from_address(address: str) -> str:
    """'Jo.Smith@Mail.Example.com' -> 'mail.example.com'."""
    if "@" not in address:
        return ""
    return address.rsplit("@", 1)[1].strip().strip(">").lower().rstrip(".")


def is_ip_address(host: str) -> bool:
    """True for hosts such as '203.0.113.7' or '[2001:db8::1]'."""
    try:
        ipaddress.ip_address(host.strip("[]"))
        return True
    except ValueError:
        return False


def registered_domain(host: str) -> str:
    """Reduce a hostname to the part someone actually registered.

    'www.harbourlinebank.com.au'                -> 'harbourlinebank.com.au'
    'harbourlinebank.com.au.secure-login.top'   -> 'secure-login.top'
    '203.0.113.7'                               -> '203.0.113.7'
    """
    host = (host or "").lower().strip().strip(".")
    host = host.split(":")[0] if not host.startswith("[") else host
    if not host:
        return ""
    if is_ip_address(host):
        return host
    labels = [label for label in host.split(".") if label]
    if len(labels) >= 3 and ".".join(labels[-2:]) in MULTI_PART_SUFFIXES:
        return ".".join(labels[-3:])
    return ".".join(labels[-2:])


def tld(host: str) -> str:
    """'login.example.top' -> 'top'."""
    host = (host or "").lower().strip(".")
    return "" if is_ip_address(host) or "." not in host else host.rsplit(".", 1)[1]


def subdomain_depth(host: str) -> int:
    """Number of labels in front of the registered domain.

    'www.cloudnest.com' -> 1, 'a.b.c.secure-login.top' -> 3.
    """
    host = (host or "").lower().strip(".")
    reg = registered_domain(host)
    if not reg or host == reg or is_ip_address(host):
        return 0
    return host[: -len(reg)].rstrip(".").count(".") + 1


def is_free_webmail(host: str) -> bool:
    return registered_domain(host) in FREE_WEBMAIL_DOMAINS


def is_trusted_domain(host: str) -> bool:
    """True if the host's registered domain is a known trusted service.

    Matches real domains only, so a look-alike such as ``g00gle.com`` or
    ``google.com.secure-login.top`` does NOT match (its registered domain is
    not ``google.com``).
    """
    return registered_domain(host) in TRUSTED_DOMAINS


# ---------------------------------------------------------------------------
# Lookalike detection
# ---------------------------------------------------------------------------

# Characters attackers swap in because they look alike at a glance.
_CONFUSABLES = (("rn", "m"), ("vv", "w"), ("0", "o"), ("1", "l"), ("3", "e"),
                ("4", "a"), ("5", "s"), ("7", "t"), ("8", "b"), ("!", "i"))


def deconfuse(text: str) -> str:
    """Undo common look-alike tricks: 'harb0ur1ine' -> 'harbourline'."""
    text = text.lower()
    for fake, real in _CONFUSABLES:
        text = text.replace(fake, real)
    return text


def edit_distance(a: str, b: str) -> int:
    """Levenshtein distance: how many single-letter edits turn a into b."""
    if a == b:
        return 0
    if len(a) < len(b):
        a, b = b, a
    previous = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        current = [i]
        for j, cb in enumerate(b, 1):
            current.append(min(previous[j] + 1,          # deletion
                               current[j - 1] + 1,       # insertion
                               previous[j - 1] + (ca != cb)))  # substitution
        previous = current
    return previous[-1]


@dataclass(frozen=True)
class Protected:
    """A name worth protecting from imitation (a brand, or your own domain)."""

    label: str
    token: str
    domains: tuple[str, ...]


def protected_names(recipient_domain: str = "") -> list[Protected]:
    """Known brands, plus the recipient's own organisation if we know it."""
    names = [Protected(b.name, b.token, b.domains) for b in KNOWN_BRANDS]
    reg = registered_domain(recipient_domain)
    brand_domains = {d for b in KNOWN_BRANDS for d in b.domains}
    if reg and not is_free_webmail(reg) and reg not in brand_domains and not is_ip_address(reg):
        core = reg.split(".")[0].replace("-", "")
        if len(core) >= 5:   # very short names cause too many false matches
            names.append(Protected("your organisation", core, (reg,)))
    return names


def find_lookalike(host: str, protected: Iterable[Protected]) -> Protected | None:
    """Return the protected name that ``host`` imitates, or None.

    A host counts as a lookalike when it is NOT one of the genuine domains but
    either (a) contains the protected word after undoing look-alike tricks, or
    (b) its main label is only one or two letters away from a genuine one.
    """
    host = (host or "").lower().strip(".")
    if not host or is_ip_address(host):
        return None
    reg = registered_domain(host)
    squashed = deconfuse(host).replace(".", "").replace("-", "")
    main_label = deconfuse(reg.split(".")[0]).replace("-", "")
    for item in protected:
        if reg in item.domains:
            return None          # the real thing
    for item in protected:
        if item.token in squashed:
            return item
        for genuine in item.domains:
            genuine_label = genuine.split(".")[0].replace("-", "")
            allowed = 2 if len(genuine_label) >= 9 else 1
            if len(genuine_label) >= 5 and 0 < edit_distance(main_label, genuine_label) <= allowed:
                return item
            if main_label == genuine_label:      # same name, different ending
                return item
    return None
