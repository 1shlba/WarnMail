"""Turn whatever the user pasted (or opened) into a structured email.

Users rarely have a clean, complete email. WarnMail has to cope with:

* text pasted from an email client, with header lines such as
  ``From:``, ``To:``, ``Subject:`` at the top (Outlook adds ``Sent:``);
* just the body, with no sender details at all;
* links shown the Outlook way, ``visible text<https://real.destination>``;
* raw HTML, or a complete ``.eml`` file (MIME) with HTML parts and real
  attachments.

``parse_email`` handles all of these and returns a ``ParsedEmail``. Nothing
here judges whether the email is dangerous; that happens in ``signals.py``.
"""

from __future__ import annotations

import email
import email.policy
import html
import re
from dataclasses import dataclass, field
from email.utils import getaddresses, parseaddr
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlsplit

from warnmail.domains import host_from_address, registered_domain
from warnmail.indicators import ALL_ATTACHMENT_EXTENSIONS

# Header lines we recognise at the top of pasted text.
PASTED_HEADER_NAMES = {
    "from", "sent", "date", "to", "cc", "bcc", "subject", "reply-to",
    "return-path", "sender", "attachments", "attachment", "importance",
}
_HEADER_LINE = re.compile(r"^(?P<name>[A-Za-z][A-Za-z-]{1,20}):[ \t]*(?P<value>.*)$")
_MIME_MARKER = re.compile(
    r"^(?:MIME-Version|Content-Type|Received|Message-ID|DKIM-Signature):", re.IGNORECASE | re.MULTILINE
)
_BARE_URL = re.compile(r"(?:https?://|www\.)[^\s<>\"'\]\)]+", re.IGNORECASE)
_ANGLE_URL = re.compile(r"<(?P<url>(?:https?://|www\.)[^>\s]+)>", re.IGNORECASE)
_LOOKS_LIKE_HTML = re.compile(r"<(?:html|body|div|p|br|table|span|a\s+href)\b", re.IGNORECASE)
_ATTACHMENT_LINE = re.compile(
    r"^\s*\[?\s*(?:attachments?|attached file)\s*[:\-]\s*(?P<names>[^\]]+?)\s*\]?\s*$",
    re.IGNORECASE | re.MULTILINE,
)
_EXTENSIONS = "|".join(sorted(ALL_ATTACHMENT_EXTENSIONS, key=len, reverse=True))
_FILENAME = re.compile(
    # The lookahead lets a filename end a sentence ("see invoice.pdf.") while
    # still refusing to match the start of something longer ("site.com.au").
    r"(?<![\w/@.\-])(?P<name>[\w\-()]+(?:\.[\w\-()]+)*\.(?:" + _EXTENSIONS + r"))(?=$|[^\w.]|\.(?!\w))",
    re.IGNORECASE,
)
_SIZE_SUFFIX = re.compile(r"\s*\(\s*\d+(?:[.,]\d+)?\s*(?:b|kb|mb|gb|bytes)\s*\)\s*$", re.IGNORECASE)


@dataclass
class Link:
    """A link found in the email.

    ``url`` is where the link really goes. ``text`` is what the reader sees
    (anchor text in HTML, or the text Outlook shows before ``<url>``); it is
    empty when we only know the bare URL.
    """

    url: str
    text: str = ""

    @property
    def host(self) -> str:
        return link_host(self.url)

    @property
    def domain(self) -> str:
        return registered_domain(self.host)


@dataclass
class ParsedEmail:
    raw: str
    source_format: str                     # "body only", "pasted with headers", "email file (MIME)"
    headers: dict[str, str] = field(default_factory=dict)
    from_name: str = ""
    from_address: str = ""
    reply_to: str = ""
    to: str = ""
    subject: str = ""
    body: str = ""
    links: list[Link] = field(default_factory=list)
    attachments: list[str] = field(default_factory=list)

    @property
    def has_sender(self) -> bool:
        return bool(self.from_address)

    @property
    def from_host(self) -> str:
        return host_from_address(self.from_address)

    @property
    def from_domain(self) -> str:
        return registered_domain(self.from_host)

    @property
    def reply_to_domain(self) -> str:
        return registered_domain(host_from_address(self.reply_to))

    @property
    def recipient_domain(self) -> str:
        addresses = [addr for _, addr in getaddresses([self.to]) if "@" in addr]
        return registered_domain(host_from_address(addresses[0])) if addresses else ""


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------

def normalise_url(url: str) -> str:
    """Tidy a URL found in text: trim punctuation and add a missing scheme."""
    url = html.unescape(url.strip().strip("'\"<>"))
    url = url.rstrip(".,;:!?'\")]}")
    if url.lower().startswith("www."):
        url = "http://" + url
    return url


def link_host(url: str) -> str:
    """Hostname a URL really points to. Handles tricks like user@host."""
    try:
        return (urlsplit(url).hostname or "").lower().rstrip(".")
    except ValueError:
        return ""


def _split_address(value: str) -> tuple[str, str]:
    """'Jo Smith <jo@x.com>' -> ('Jo Smith', 'jo@x.com')."""
    value = value.strip()
    # Outlook sometimes writes: Jo Smith [mailto:jo@x.com]
    value = re.sub(r"\[mailto:([^\]]+)\]", r"<\1>", value, flags=re.IGNORECASE)
    name, address = parseaddr(value)
    if "@" not in address:
        found = re.search(r"[\w.+'-]+@[\w-]+(?:\.[\w-]+)+", value)
        if not found:
            return value.strip('" '), ""
        address = found.group(0)
        name = value.replace(address, "").strip(' "<>')
    return name.strip().strip('"').strip(), address.strip().lower()


def _attachment_names(value: str) -> list[str]:
    names = []
    for chunk in re.split(r"[;,]|\s{2,}", value):
        chunk = _SIZE_SUFFIX.sub("", chunk.strip().strip("[]"))
        if chunk and _FILENAME.search(chunk):
            names.append(chunk)
    return names


def _dedupe(items: list[str]) -> list[str]:
    seen, result = set(), []
    for item in items:
        key = item.lower()
        if key not in seen:
            seen.add(key)
            result.append(item)
    return result


class _HTMLToText(HTMLParser):
    """Convert HTML to plain text while remembering every link."""

    _BLOCK_TAGS = {"p", "div", "br", "tr", "li", "h1", "h2", "h3", "h4", "table", "hr"}

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self.links: list[Link] = []
        self._href: str | None = None
        self._anchor_text: list[str] = []
        self._skip_depth = 0

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style", "head"):
            self._skip_depth += 1
        if tag in self._BLOCK_TAGS:
            self.parts.append("\n")
        if tag == "a":
            self._href = dict(attrs).get("href") or ""
            self._anchor_text = []

    def handle_endtag(self, tag):
        if tag in ("script", "style", "head") and self._skip_depth:
            self._skip_depth -= 1
        if tag == "a" and self._href is not None:
            href = self._href.strip()
            if href.lower().startswith(("http://", "https://", "www.")):
                text = " ".join("".join(self._anchor_text).split())
                self.links.append(Link(normalise_url(href), text))
            self._href = None
        if tag in self._BLOCK_TAGS:
            self.parts.append("\n")

    def handle_data(self, data):
        if self._skip_depth:
            return
        self.parts.append(data)
        if self._href is not None:
            self._anchor_text.append(data)

    def text(self) -> str:
        joined = "".join(self.parts)
        lines = [" ".join(line.split()) for line in joined.splitlines()]
        return re.sub(r"\n{3,}", "\n\n", "\n".join(lines)).strip()


def html_to_text(markup: str) -> tuple[str, list[Link]]:
    converter = _HTMLToText()
    try:
        converter.feed(markup)
        converter.close()
    except Exception:  # malformed HTML: fall back to stripping tags
        return re.sub(r"<[^>]+>", " ", markup), []
    return converter.text(), converter.links


def extract_text_links(body: str) -> list[Link]:
    """Find links in plain text, including Outlook-style 'text<url>' links."""
    links: list[Link] = []
    masked = body

    def blank(text: str, start: int, end: int) -> str:
        return text[:start] + " " * (end - start) + text[end:]

    for match in _ANGLE_URL.finditer(body):
        line_start = body.rfind("\n", 0, match.start()) + 1
        before = body[line_start:match.start()]
        # Only keep text after the previous link on the same line.
        before = before.rsplit(">", 1)[-1]
        words = before.strip().split()
        text = " ".join(words[-8:])
        links.append(Link(normalise_url(match.group("url")), text))
        masked = blank(masked, match.start(), match.end())
        # If the visible text is itself a web address ("www.bank.com<http://evil>"),
        # it is only a label - don't count it again as a separate link.
        shown = re.search(r"(?:https?://|www\.)\S+\s*$", before)
        if shown:
            masked = blank(masked, match.start() - len(before) + shown.start(), match.start())
    for match in _BARE_URL.finditer(masked):
        links.append(Link(normalise_url(match.group(0))))
    return [link for link in links if link.host]


def extract_body_attachments(body: str) -> list[str]:
    """Attachment names mentioned in the body ('[Attachment: x.pdf]', 'x.pdf.exe')."""
    names: list[str] = []
    for match in _ATTACHMENT_LINE.finditer(body):
        names.extend(_attachment_names(match.group("names")))
    without_urls = _BARE_URL.sub(" ", _ANGLE_URL.sub(" ", body))
    without_emails = re.sub(r"[\w.+'-]+@[\w-]+(?:\.[\w-]+)+", " ", without_urls)
    for match in _FILENAME.finditer(without_emails):
        names.append(match.group("name"))
    return names


# ---------------------------------------------------------------------------
# Parsers for the three input styles
# ---------------------------------------------------------------------------

def _parse_mime(text: str) -> ParsedEmail:
    message = email.message_from_string(text, policy=email.policy.default)
    headers = {name.lower(): str(value) for name, value in message.items()}
    plain_parts, html_parts, attachments = [], [], []
    for part in message.walk():
        if part.is_multipart():
            continue
        filename = part.get_filename()
        if filename or part.get_content_disposition() == "attachment":
            attachments.append(filename or "(unnamed attachment)")
            continue
        try:
            content = part.get_content()
        except Exception:
            payload = part.get_payload(decode=True) or b""
            content = payload.decode("utf-8", errors="replace")
        if not isinstance(content, str):
            continue
        if part.get_content_type() == "text/html":
            html_parts.append(content)
        elif part.get_content_type() == "text/plain":
            plain_parts.append(content)

    links: list[Link] = []
    html_text = ""
    for markup in html_parts:
        part_text, part_links = html_to_text(markup)
        html_text += part_text + "\n"
        links.extend(part_links)
    body = "\n".join(plain_parts).strip() or html_text.strip()
    if not html_parts:
        links = extract_text_links(body)

    from_name, from_address = _split_address(headers.get("from", ""))
    _, reply_to = _split_address(headers.get("reply-to", "")) if headers.get("reply-to") else ("", "")
    return ParsedEmail(
        raw=text, source_format="email file (MIME)", headers=headers,
        from_name=from_name, from_address=from_address, reply_to=reply_to,
        to=headers.get("to", ""), subject=headers.get("subject", "").strip(),
        body=body, links=links,
        attachments=_dedupe(attachments + extract_body_attachments(body)),
    )


def _split_pasted_headers(text: str) -> tuple[dict[str, str], str]:
    """Split pasted text into (header dict, body). Headers may be absent."""
    lines = text.split("\n")
    index = 0
    while index < len(lines) and not lines[index].strip():
        index += 1

    headers: dict[str, str] = {}
    current = None
    # Gmail-style copy: the first line is just "Name <address>".
    first = lines[index] if index < len(lines) else ""
    if re.fullmatch(r"\s*[^<>@\n:]{1,60}<[^@\s>]+@[^>\s]+>\s*", first):
        headers["from"] = first.strip()
        index += 1
    while index < len(lines):
        line = lines[index]
        match = _HEADER_LINE.match(line)
        if match and match.group("name").lower() in PASTED_HEADER_NAMES:
            current = match.group("name").lower()
            value = match.group("value").strip()
            headers[current] = f"{headers[current]}; {value}" if current in headers else value
        elif current and line[:1] in (" ", "\t") and line.strip():
            headers[current] += " " + line.strip()
        else:
            break
        index += 1

    if not ({"from", "subject"} & headers.keys()):
        return {}, text
    return headers, "\n".join(lines[index:]).strip("\n")


def _parse_pasted(text: str) -> ParsedEmail:
    headers, body = _split_pasted_headers(text)
    links: list[Link]
    if _LOOKS_LIKE_HTML.search(body):
        body, links = html_to_text(body)
        known = {link.url for link in links}
        links += [link for link in extract_text_links(body) if link.url not in known]
    else:
        links = extract_text_links(body)

    attachments: list[str] = []
    for key in ("attachments", "attachment"):
        if key in headers:
            attachments.extend(_attachment_names(headers[key]))
    attachments.extend(extract_body_attachments(body))

    from_name, from_address = _split_address(headers.get("from", "")) if headers.get("from") else ("", "")
    reply_to = _split_address(headers["reply-to"])[1] if headers.get("reply-to") else ""
    return ParsedEmail(
        raw=text, source_format="pasted with headers" if headers else "body only",
        headers=headers, from_name=from_name, from_address=from_address,
        reply_to=reply_to, to=headers.get("to", ""),
        subject=headers.get("subject", "").strip(), body=body.strip(),
        links=links, attachments=_dedupe(attachments),
    )


def parse_email(text: str) -> ParsedEmail:
    """Parse pasted text or the contents of an .eml file."""
    text = (text or "").replace("\r\n", "\n").replace("\r", "\n").lstrip("﻿")
    text = text.replace("’", "'").replace("‘", "'")   # curly apostrophes
    head = "\n".join(text.lstrip().split("\n")[:60])
    if _MIME_MARKER.search(head):
        try:
            return _parse_mime(text.lstrip())
        except Exception:
            pass  # not valid MIME after all - treat it as pasted text
    return _parse_pasted(text)


def read_email_file(path: str | Path) -> str:
    """Read a .txt or .eml file, coping with the usual text encodings."""
    data = Path(path).read_bytes()
    for encoding in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace")
