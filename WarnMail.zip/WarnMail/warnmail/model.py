"""Load, save and use the trained Random Forest.

The model is stored as a "bundle": the fitted scikit-learn model *plus* the
list of feature names it was trained with and some metadata (training date,
library versions, evaluation scores, which emails were held out for
testing). Storing the feature names next to the model lets us check, every
time the app starts, that the app and the model agree on what each number
means.

Security note: model files are Python pickles. Loading a pickle can run code,
so only ever load model files you created yourself.
"""

from __future__ import annotations

import warnings
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

from warnmail.features import FEATURE_NAMES, to_vector


class ModelError(Exception):
    """The model is missing, unreadable or does not match this version of WarnMail."""


@dataclass
class ModelBundle:
    model: object                                  # a fitted RandomForestClassifier
    feature_names: list[str]
    metadata: dict = field(default_factory=dict)
    load_warnings: list[str] = field(default_factory=list)

    @property
    def phishing_index(self) -> int:
        """Column of predict_proba() that holds P(phishing)."""
        return list(self.model.classes_).index(1)


@dataclass
class Contribution:
    feature: str
    value: float
    effect: float        # change in phishing probability, e.g. +0.12


@dataclass
class Explanation:
    baseline: float                  # average prediction before looking at this email
    contributions: list[Contribution]


def save_bundle(bundle: ModelBundle, path: Path) -> None:
    import joblib

    path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump({"model": bundle.model, "feature_names": bundle.feature_names,
                 "metadata": bundle.metadata}, path, compress=3)


def load_bundle(path: Path) -> ModelBundle:
    """Load a model bundle and check it fits this version of WarnMail."""
    import joblib

    path = Path(path)
    if not path.exists():
        raise ModelError(f"No trained model was found at {path}. "
                         "Train one with:  python -m training.train_model")
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        try:
            data = joblib.load(path)
        except Exception as exc:
            raise ModelError(f"The model file could not be loaded ({type(exc).__name__}: {exc}). "
                             "Retrain it with:  python -m training.train_model") from exc
    # scikit-learn warns when a model was saved with a different version.
    version_warnings = [str(w.message).splitlines()[0] for w in caught
                        if "version" in str(w.message).lower()]

    if not isinstance(data, dict) or "model" not in data or "feature_names" not in data:
        raise ModelError("The model file is not a WarnMail model bundle.")
    bundle = ModelBundle(model=data["model"], feature_names=list(data["feature_names"]),
                         metadata=dict(data.get("metadata", {})), load_warnings=version_warnings)
    check_feature_names(bundle)
    return bundle


def check_feature_names(bundle: ModelBundle) -> None:
    """Refuse to use a model trained on a different feature list."""
    if bundle.feature_names == FEATURE_NAMES:
        return
    missing = [n for n in FEATURE_NAMES if n not in bundle.feature_names]
    extra = [n for n in bundle.feature_names if n not in FEATURE_NAMES]
    detail = []
    if missing:
        detail.append(f"missing {', '.join(missing)}")
    if extra:
        detail.append(f"unexpected {', '.join(extra)}")
    if not detail:
        detail.append("same features but in a different order")
    raise ModelError("The model was trained with a different feature list "
                     f"({'; '.join(detail)}). Retrain with:  python -m training.train_model")


def predict_probability(bundle: ModelBundle, features: dict[str, float]) -> float:
    """Probability (0-1) that the email is phishing."""
    x = np.array([to_vector(features, bundle.feature_names)], dtype=float)
    return float(bundle.model.predict_proba(x)[0, bundle.phishing_index])


def explain_prediction(bundle: ModelBundle, features: dict[str, float], top: int | None = 6) -> Explanation:
    """Explain one prediction by following its path through every tree.

    Each decision tree starts from a baseline (the share of phishing emails
    it was trained on) and every split on the way down to a leaf moves the
    probability up or down. Crediting each move to the feature used at that
    split gives a per-feature "effect". Averaged over all trees:

        baseline + sum(effects) == the model's predicted probability

    (This is the "Saabas" method, also used by the treeinterpreter package.)
    """
    names = bundle.feature_names
    # Trees compare float32 inputs against their thresholds, so do the same.
    x = np.array(to_vector(features, names), dtype=np.float32)
    column = bundle.phishing_index
    effects = np.zeros(len(names))
    baseline = 0.0
    trees = bundle.model.estimators_
    for estimator in trees:
        tree = estimator.tree_
        values = tree.value[:, 0, :]
        totals = values.sum(axis=1, keepdims=True)
        share = values[:, column] / np.where(totals[:, 0] == 0, 1, totals[:, 0])
        node = 0
        baseline += share[node]
        while tree.children_left[node] != -1:          # -1 means "leaf"
            feature = tree.feature[node]
            if x[feature] <= tree.threshold[node]:
                child = tree.children_left[node]
            else:
                child = tree.children_right[node]
            effects[feature] += share[child] - share[node]
            node = child
    effects /= len(trees)
    baseline /= len(trees)
    ranked = sorted(range(len(names)), key=lambda i: abs(effects[i]), reverse=True)
    if top is None:              # every feature, e.g. for testing the maths
        selected = ranked
    else:                        # the biggest few, ignoring tiny effects
        selected = [i for i in ranked[:top] if abs(effects[i]) >= 0.005]
    contributions = [Contribution(names[i], float(x[i]), float(effects[i])) for i in selected]
    return Explanation(baseline=float(baseline), contributions=contributions)
