"""Word lists ("lexicons") for the language phishing emails tend to use.

Each category below is a list of phrases. ``find_phrases`` returns which
phrases from a category appear in a piece of text. Matching is
case-insensitive, ignores extra spaces and only matches whole words, so
"fine" does not match inside "refined".

Most phrases also appear in perfectly normal emails ("invoice", "password",
"deadline"). That is expected: a single phrase is weak evidence. The rule
engine and the model both look at *combinations* of signals.
"""

from __future__ import annotations

import re
from dataclasses import dataclass


@dataclass(frozen=True)
class Pattern:
    label: str            # what we show the user as evidence
    regex: re.Pattern


def _phrase(text: str) -> Pattern:
    # Escape the phrase, let any run of whitespace match a space, and refuse
    # to match in the middle of a word.
    body = r"\s+".join(re.escape(word) for word in text.split())
    return Pattern(text, re.compile(r"(?<![a-z0-9])" + body + r"(?![a-z0-9])", re.IGNORECASE))


def _regex(label: str, pattern: str) -> Pattern:
    return Pattern(label, re.compile(pattern, re.IGNORECASE))


def phrases(*items: str) -> tuple[Pattern, ...]:
    return tuple(_phrase(item) for item in items)


URGENCY = phrases(
    "urgent", "urgently", "immediately", "immediate action", "action required",
    "act now", "as soon as possible", "asap", "right away", "straight away",
    "today only", "by end of day", "by close of business", "end of the day",
    "final notice", "final reminder", "last chance", "last warning",
    "time sensitive", "time-sensitive", "don't delay", "do not delay",
    "respond now", "without delay", "promptly", "expires today", "deadline",
) + (
    _regex("within a few hours", r"within\s+(?:the\s+next\s+)?\d{1,2}\s*(?:hours?|hrs?)"),
    _regex("expires soon", r"expir(?:e|es|ing)\s+(?:in|within)\s+\d+\s*(?:hours?|hrs?|minutes?|mins?|days?)"),
    _regex("before a time today", r"before\s+\d{1,2}(?::\d{2})?\s*(?:am|pm)\s+today"),
)

THREAT = phrases(
    "suspended", "suspension", "locked", "temporarily locked", "disabled",
    "deactivated", "deactivation", "terminated", "closed permanently",
    "permanently deleted", "will be deleted", "lose access", "loss of access",
    "legal action", "debt collection", "penalty", "penalties", "fines",
    "fined", "late fee", "late fees", "arrest", "warrant", "unauthorised",
    "unauthorized", "unusual activity", "suspicious activity",
    "unusual sign-in", "unusual sign in", "security breach", "compromised",
    "restricted", "service interruption", "disconnection", "disconnected",
    "blacklisted", "frozen",
)

CREDENTIAL = phrases(
    "verify your account", "verify your identity", "verify your details",
    "verify your email", "confirm your account", "confirm your identity",
    "confirm your password", "confirm your details", "update your details",
    "update your account", "update your information", "validate your account",
    "re-enter your password", "enter your password", "log in to", "login to",
    "log into", "sign in to", "sign in now", "sign in below", "login details",
    "login credentials", "your credentials", "username and password",
    "password", "passcode", "verification code", "one-time code",
    "one time code", "security code", "mfa code", "authentication code",
    "reset your password", "password reset", "keep your password",
    "keep your current password", "security questions",
)

PAYMENT = phrases(
    "invoice", "payment", "pay now", "make a payment", "outstanding balance",
    "outstanding amount", "overdue", "amount due", "bank details",
    "banking details", "bank account", "account details", "bsb",
    "account number", "wire transfer", "bank transfer", "eft", "remittance",
    "transfer the funds", "process a payment", "process the payment",
    "urgent payment", "refund", "reimbursement", "direct debit",
    "credit card", "card details", "redelivery fee", "small fee",
    "customs fee", "processing fee", "settle", "settlement",
)

# A narrower, much stronger list: "our bank details have changed" is the
# classic business email compromise (BEC) move.
BANK_CHANGE = phrases(
    "new bank account", "new account details", "updated bank details",
    "updated banking details", "change of bank details", "changed our bank",
    "changed banks", "changed our banking", "our banking details have changed",
    "our bank details have changed", "new banking details", "new bsb",
    "update your records with", "use the new account", "our new account",
)

SECRECY = phrases(
    "keep this confidential", "keep this between us", "strictly confidential",
    "confidential matter", "don't tell", "do not tell", "don't mention",
    "do not discuss", "quietly", "discreet", "discreetly", "i'm in a meeting",
    "i am in a meeting", "in a meeting", "can't talk", "cannot talk",
    "can't take calls", "unable to take calls", "unable to call", "don't call",
    "do not call", "reply by email only", "email only", "are you at your desk",
    "are you available", "quick favour", "quick favor", "i need a favour",
    "i need a favor", "i need you to", "surprise for the staff",
    "surprise for the team", "before i get back",
)

GIFT_CARD = phrases(
    "gift card", "gift cards", "itunes card", "apple gift", "google play card",
    "google play gift", "steam card", "steam wallet", "amazon gift",
    "visa gift", "prepaid card", "prepaid cards", "scratch the back",
    "scratch off", "photo of the back", "pictures of the back", "the codes",
    "card codes",
)

SENSITIVE_INFO = phrases(
    "tax file number", "tfn", "date of birth", "driver licence",
    "driver's licence", "drivers licence", "licence number", "license number",
    "passport number", "medicare number", "medicare card",
    "credit card number", "card number", "cvv", "cvc", "expiry date",
    "pin number", "your pin", "mother's maiden name", "bank login",
    "online banking password",
)

REWARD = phrases(
    "congratulations", "you have won", "you've won", "winner", "prize",
    "claim your", "claim now", "reward", "free gift", "bonus", "lottery",
    "selected to receive", "cash prize", "you are eligible", "you're eligible",
    "eligible for a refund", "tax refund", "unclaimed", "voucher",
)

CLICK = phrases(
    "click here", "click the link", "click below", "click the button",
    "follow the link", "use the link below", "tap here", "open the attachment",
    "open the attached", "download the attached", "view document",
    "view the document", "review document", "access the document",
    "view message", "view invoice", "listen to message", "listen now",
    "sign in below", "verify now", "update now", "pay now", "confirm now",
)

# Grouped so the rest of the code can loop over them.
CATEGORIES: dict[str, tuple[Pattern, ...]] = {
    "urgency": URGENCY,
    "threat": THREAT,
    "credential": CREDENTIAL,
    "payment": PAYMENT,
    "bank_change": BANK_CHANGE,
    "secrecy": SECRECY,
    "gift_card": GIFT_CARD,
    "sensitive_info": SENSITIVE_INFO,
    "reward": REWARD,
    "click": CLICK,
}

GENERIC_GREETING = (
    re.compile(
        r"^\s*(?:dear|hello|hi|greetings|attention)[\s,:]+(?:valued\s+|our\s+)?"
        r"(?:customer|client|user|member|account\s*holder|sir|madam|sir\s*/\s*madam|"
        r"sir\s+or\s+madam|e-?mail\s+user|subscriber|beneficiary|employee|"
        r"staff(?:\s+member)?|team\s+member|colleague|recipient|account\s+owner)s?\b",
        re.IGNORECASE | re.MULTILINE,
    ),
    # "Dear jo.smith@company.com" - greeting someone by their address.
    re.compile(r"^\s*(?:dear|hello|hi)\s+[\w.+-]+@[\w-]+\.[\w.-]+", re.IGNORECASE | re.MULTILINE),
)

# ---------------------------------------------------------------------------
# Attachments
# ---------------------------------------------------------------------------
EXECUTABLE_EXTENSIONS = {
    # ".com" is left out on purpose: it would match every "example.com".
    "exe", "scr", "pif", "bat", "cmd", "js", "jse", "vbs", "vbe",
    "wsf", "ps1", "msi", "jar", "hta", "lnk", "cpl", "reg",
}
DISK_IMAGE_EXTENSIONS = {"iso", "img", "vhd", "vhdx"}
WEB_PAGE_EXTENSIONS = {"htm", "html", "shtml", "svg"}
MACRO_EXTENSIONS = {"docm", "xlsm", "pptm", "dotm", "xlam"}
ARCHIVE_EXTENSIONS = {"zip", "rar", "7z", "gz", "cab", "ace"}
DOCUMENT_EXTENSIONS = {"pdf", "doc", "docx", "xls", "xlsx", "csv", "ppt",
                       "pptx", "txt", "rtf", "png", "jpg", "jpeg", "gif",
                       "wav", "mp3", "m4a", "ics", "odt", "ods"}

ALL_ATTACHMENT_EXTENSIONS = (EXECUTABLE_EXTENSIONS | DISK_IMAGE_EXTENSIONS |
                             WEB_PAGE_EXTENSIONS | MACRO_EXTENSIONS |
                             ARCHIVE_EXTENSIONS | DOCUMENT_EXTENSIONS)


def find_phrases(text: str, patterns: tuple[Pattern, ...]) -> list[str]:
    """Return every phrase found in ``text``, as it appears (no duplicates).

    The count of distinct phrases is used as a feature, and the phrases
    themselves are shown to the user as evidence.
    """
    if not text:
        return []
    found: list[str] = []
    for pattern in patterns:
        match = pattern.regex.search(text)
        if match:
            phrase = " ".join(match.group(0).split()).lower()
            if phrase not in found:
                found.append(phrase)
    return found


def find_generic_greeting(body: str) -> str | None:
    """Return the generic greeting line ("Dear Customer,"), if any."""
    head = "\n".join([line for line in body.splitlines() if line.strip()][:4])
    for pattern in GENERIC_GREETING:
        match = pattern.search(head)
        if match:
            return match.group(0).strip()
    return None
