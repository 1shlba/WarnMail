"""WarnMail: a small, offline phishing-email checker for non-technical users.

WarnMail combines two independent checks:

1. A rule engine that looks for well-known warning signs (urgent threats,
   requests for passwords or payment, disguised links, risky attachments...)
   and explains each one in plain language.
2. A Random Forest model trained on labelled example emails, which spots
   combinations of signals that simple rules can miss.

The two results are blended into a Low / Medium / High risk rating.

Typical use from Python::

    from warnmail.analyzer import Analyzer
    result = Analyzer().analyse(email_text)
    print(result.report.to_text())

This package is a learning prototype. It is not a replacement for a proper
email security service.
"""

__version__ = "1.0.0"
