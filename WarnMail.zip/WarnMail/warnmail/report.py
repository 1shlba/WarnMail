"""The result object WarnMail hands back, plus plain-text formatting.

``AnalysisResult`` is what every part of the app (GUI, command line, tests)
receives. It carries the final risk level and score, the rule findings, the
model's view, and a short "what should I do" message. ``to_text`` renders it
as the report the user can read, copy or save.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from warnmail import config
from warnmail.features import FEATURE_DESCRIPTIONS
from warnmail.rules import Finding

RISK_LEVELS = ("Low", "Medium", "High")

ADVICE = {
    "Low": "Nothing obvious stood out. Stay alert anyway: if anything feels off, "
           "check with the sender using contact details you already have.",
    "Medium": "Treat this email with caution. Do not click links, open attachments, "
              "reply with any details, or pay anything until you have confirmed it is "
              "genuine through a channel you trust.",
    "High": "This email has strong signs of phishing. Do not click any links, open "
            "attachments, reply, or act on it. If it claims to be from someone you know, "
            "contact them using details you already have. Consider reporting it.",
}


def level_from_score(score: float) -> str:
    if score >= config.HIGH_THRESHOLD:
        return "High"
    if score >= config.MEDIUM_THRESHOLD:
        return "Medium"
    return "Low"


@dataclass
class ModelView:
    """What the Random Forest contributed (absent when no model is loaded)."""
    available: bool
    probability: float = 0.0                 # 0-1
    reasons: list[str] = field(default_factory=list)
    note: str = ""                           # e.g. why the model is unavailable

    @property
    def percent(self) -> int:
        return round(self.probability * 100)


@dataclass
class AnalysisResult:
    mode: str                                # "hybrid", "rules" or "model"
    level: str                               # "Low" / "Medium" / "High"
    score: int                               # 0-100
    rule_score: int
    findings: list[Finding]
    model: ModelView
    advice: str
    summary: str                             # one-line headline
    overrides: list[str] = field(default_factory=list)
    source_format: str = ""
    sender: str = ""
    subject: str = ""

    @property
    def is_flagged(self) -> bool:
        return self.level in ("Medium", "High")

    # -- plain-text rendering ------------------------------------------------
    def to_text(self, width: int = 72) -> str:
        line = "=" * width
        out = [line, f"WarnMail result: {self.level.upper()} RISK  (score {self.score}/100)",
               line, self.summary, ""]
        if self.subject:
            out.append(f"Subject: {self.subject}")
        if self.sender:
            out.append(f"From:    {self.sender}")
        if self.subject or self.sender:
            out.append("")

        if self.findings:
            out.append(f"Warning signs found ({len(self.findings)}):")
            for finding in self.findings:
                out.append(f"  [{finding.severity.upper()}] {finding.title}")
                for sentence in _wrap(finding.detail, width - 8):
                    out.append(f"        {sentence}")
                for item in finding.evidence:
                    out.append(f"          - {item}")
            out.append("")
        elif self.mode != "model":
            out.append("Warning signs found: none.\n")

        if self.model.available:
            out.append(f"Machine-learning model: {self.model.percent}% likely phishing.")
            for reason in self.model.reasons:
                out.append(f"  - {reason}")
            out.append("")
        elif self.model.note and self.mode in ("hybrid", "model"):
            out.append(f"Machine-learning model: {self.model.note}\n")

        if self.overrides:
            out.append("Adjustments:")
            out.extend(f"  - {item}" for item in self.overrides)
            out.append("")

        out.append("What to do:")
        out.extend(f"  {sentence}" for sentence in _wrap(self.advice, width - 2))
        out += ["", line,
                "WarnMail is a learning prototype, not a security guarantee.",
                "Always use your own judgement.", line]
        return "\n".join(out)

    def describe_feature(self, name: str) -> str:
        return FEATURE_DESCRIPTIONS.get(name, name)


def _wrap(text: str, width: int) -> list[str]:
    import textwrap
    lines: list[str] = []
    for paragraph in text.split("\n"):
        lines.extend(textwrap.wrap(paragraph, width) or [""])
    return lines
