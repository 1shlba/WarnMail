"""The analyzer: combine the rules and the model into one result.

This is the part students are usually most interested in, because it is
where the "hybrid" idea lives. The flow is:

    text -> parse -> detect signals -> (rules) + (model) -> blend -> result

Three modes are supported so the three approaches can be compared:

* ``"rules"``  - rule score only
* ``"model"``  - Random Forest probability only
* ``"hybrid"`` - a weighted blend of the two, plus safety overrides

The safety overrides matter: a single very strong, specific sign (a
disguised link, a gift-card request) should not be averaged away by a model
that is only mildly suspicious. So the hybrid and rules modes lift the level
when high-severity findings are present.
"""

from __future__ import annotations

from pathlib import Path

from warnmail import config
from warnmail.features import FEATURE_DESCRIPTIONS, extract_features
from warnmail.model import (ModelBundle, ModelError, explain_prediction,
                            load_bundle, predict_probability)
from warnmail.domains import is_trusted_domain
from warnmail.parser import ParsedEmail, parse_email, read_email_file
from warnmail.report import ADVICE, AnalysisResult, ModelView, level_from_score
from warnmail.rules import RuleResult, evaluate_rules
from warnmail.signals import Signals, detect

# How a model feature, when it pushed the score up, is explained to the user.
_MODEL_REASON_UP = {
    "body_words": "the message is very short",
    "shouting_ratio": "a lot of the text is in capitals",
    "exclamation_marks": "several exclamation marks",
    "offsite_link_ratio": "links leave the sender's own website",
    "link_count": "it contains links",
}


def _model_reason(name: str, value: float, effect: float) -> str:
    """Turn a feature's contribution into a short phrase for the user."""
    if effect > 0:
        if name in _MODEL_REASON_UP:
            return _MODEL_REASON_UP[name]
        text = FEATURE_DESCRIPTIONS.get(name, name)
        return text[0].lower() + text[1:]
    # Features that pushed the score down (towards "safe").
    calming = {
        "has_sender": "the sender's address is known",
        "body_words": "it reads like a normal-length message",
        "link_count": "it has few or no links",
        "offsite_link_ratio": "links stay on the sender's own site",
    }
    return calming.get(name, "some normal-email features are present")


class Analyzer:
    """Analyse emails. Create one and reuse it; the model loads only once.

    ``require_model=False`` (the default) means the app still runs in
    rules-only mode if the model file is missing, instead of refusing to
    start. ``analyze`` reports the situation in the result.
    """

    def __init__(self, model_path: Path | None = None, require_model: bool = False,
                 bundle: ModelBundle | None = None):
        self.model_path = Path(model_path) if model_path else config.MODEL_PATH
        self.bundle: ModelBundle | None = None
        self.model_note: str = ""
        if bundle is not None:
            # Used by the evaluation, which swaps in a fresh model per fold.
            self.bundle = bundle
            return
        try:
            self.bundle = load_bundle(self.model_path)
            if self.bundle.load_warnings:
                self.model_note = ("the saved model was built with a different library "
                                   "version; results may vary. Retraining is recommended.")
        except ModelError as exc:
            if require_model:
                raise
            self.model_note = str(exc).splitlines()[0]

    # -- convenience entry points -------------------------------------------
    def analyze_file(self, path: str | Path, mode: str = "hybrid") -> AnalysisResult:
        return self.analyze(read_email_file(path), mode=mode)

    def analyze(self, text: str, mode: str = "hybrid") -> AnalysisResult:
        if mode not in ("hybrid", "rules", "model"):
            raise ValueError(f"Unknown mode: {mode!r}")
        parsed = parse_email(text)
        signals = detect(parsed)
        features = extract_features(signals)
        rule_result = evaluate_rules(signals)
        model_view = self._run_model(features)

        if mode == "rules":
            result = self._result_rules(parsed, signals, rule_result, model_view)
        elif mode == "model":
            result = self._result_model(parsed, signals, rule_result, model_view)
        else:
            result = self._result_hybrid(parsed, signals, rule_result, model_view)

        # Decision-layer policy: trusted sources. Applied to the rules/hybrid
        # modes (like the safety overrides), not to the raw model-only view.
        if mode in ("rules", "hybrid"):
            self._apply_trusted_source(result, parsed, signals, rule_result)
        return result

    # -- trusted sources ----------------------------------------------------
    def _trusted_source(self, parsed: ParsedEmail, signals: Signals,
                        rules: RuleResult) -> str | None:
        """Return a reason if this email is safe to trust, else None.

        An allowlisted From domain alone is not enough - it can be forged - so
        trust is granted ONLY when every one of these also holds:
          * the sender's domain is on the trusted list;
          * replies would not be diverted to another domain;
          * every link stays on a trusted domain (no off-ramp to an attacker);
          * there are no high-severity findings (disguised link, gift cards,
            bank-change, risky attachment, look-alike, @-trick...).
        If an attacker forges From: google.com but links to their own site, the
        link check fails and trust is refused.
        """
        if not parsed.has_sender or not is_trusted_domain(parsed.from_host):
            return None
        if signals.sender.reply_to:                       # replies go elsewhere
            return None
        if any(not link.trusted for link in signals.links):
            return None
        if rules.high_count > 0:                           # a strong red flag
            return None
        return (f"the sender domain '{parsed.from_domain}' is a known trusted service "
                "and every link stays on a trusted domain")

    def _apply_trusted_source(self, result: AnalysisResult, parsed, signals,
                              rules: RuleResult) -> None:
        reason = self._trusted_source(parsed, signals, rules)
        if not reason or result.level == "Low":
            return
        result.score = min(result.score, config.MEDIUM_THRESHOLD - 1)
        result.level = "Low"
        result.advice = ADVICE["Low"]
        result.summary = ("No strong signs of phishing - this looks like a genuine "
                          "message from a trusted service.")
        result.overrides = result.overrides + [
            f"Lowered to Low risk because {reason}. Note: a From address can be forged, "
            "so if anything else feels off, confirm before acting."]

    # -- the model ----------------------------------------------------------
    def _run_model(self, features: dict[str, float]) -> ModelView:
        if self.bundle is None:
            return ModelView(available=False, note=self.model_note)
        probability = predict_probability(self.bundle, features)
        explanation = explain_prediction(self.bundle, features, top=5)
        reasons: list[str] = []
        for contribution in explanation.contributions:
            phrase = _model_reason(contribution.feature, contribution.value, contribution.effect)
            direction = "raises" if contribution.effect > 0 else "lowers"
            if phrase not in [r.split(" (")[0] for r in reasons]:
                reasons.append(f"{phrase} ({direction} the score)")
        return ModelView(available=True, probability=probability, reasons=reasons[:4],
                         note=self.model_note)

    # -- building each kind of result ---------------------------------------
    def _result_rules(self, parsed, signals, rules: RuleResult, model: ModelView) -> AnalysisResult:
        score = rules.score
        level, overrides = _apply_overrides(level_from_score(score), rules, score)
        quiet_model = ModelView(available=False, note="not used in rules-only mode")
        return self._assemble("rules", parsed, signals, level, score, rules, quiet_model, overrides)

    def _result_model(self, parsed, signals, rules: RuleResult, model: ModelView) -> AnalysisResult:
        if not model.available:
            # Fall back to rules so the user still gets an answer.
            result = self._result_rules(parsed, signals, rules, model)
            result.mode = "model"
            result.overrides = [f"No model available ({model.note}); showed the rule result instead."]
            return result
        score = model.percent
        level = level_from_score(score)
        result = self._assemble("model", parsed, signals, level, score, rules, model, [])
        # Model-only mode reflects the model alone, so don't show the rule
        # findings (they belong to the rules/hybrid modes). The rule score is
        # still kept on the result for comparison.
        result.findings = []
        return result

    def _result_hybrid(self, parsed, signals, rules: RuleResult, model: ModelView) -> AnalysisResult:
        if not model.available:
            result = self._result_rules(parsed, signals, rules, model)
            result.mode = "hybrid"
            result.model = model
            result.overrides = result.overrides + [
                "The model was unavailable, so this is the rules-only result."]
            result.advice = result.advice
            return result
        blended = (config.MODEL_WEIGHT * model.percent) + (config.RULES_WEIGHT * rules.score)
        score = round(blended)
        level, overrides = _apply_overrides(level_from_score(score), rules, score)
        gap = abs(model.percent - rules.score)
        if gap >= config.DISAGREEMENT_GAP:
            overrides.append(
                f"The rules ({rules.score}) and the model ({model.percent}) disagree a lot; "
                "treating it with extra caution.")
        return self._assemble("hybrid", parsed, signals, level, score, rules, model, overrides)

    def _assemble(self, mode, parsed: ParsedEmail, signals: Signals, level, score,
                  rules: RuleResult, model: ModelView, overrides) -> AnalysisResult:
        from warnmail.report import ADVICE
        summary = _summary(level, mode, rules, model, signals)
        sender = parsed.from_address or (parsed.from_name if parsed.from_name else "")
        if not parsed.has_sender and not sender:
            sender = "(no sender details in the pasted text)"
        return AnalysisResult(
            mode=mode, level=level, score=int(score), rule_score=rules.score,
            findings=list(rules.findings), model=model, advice=ADVICE[level],
            summary=summary, overrides=overrides, source_format=parsed.source_format,
            sender=sender, subject=parsed.subject,
        )


def _apply_overrides(level: str, rules: RuleResult, score: int) -> tuple[str, list[str]]:
    """Lift the level when strong, specific warning signs are present."""
    overrides: list[str] = []
    order = {"Low": 0, "Medium": 1, "High": 2}
    high = rules.high_count
    target = level
    if high >= config.HIGH_FINDINGS_FOR_HIGH:
        target = "High"
    elif high >= config.HIGH_FINDINGS_FOR_MEDIUM and order[target] < order["Medium"]:
        target = "Medium"
    if order[target] > order[level]:
        word = "sign" if high == 1 else "signs"
        overrides.append(f"Raised to {target} risk because of {high} strong warning {word}.")
    return target, overrides


def _summary(level, mode, rules: RuleResult, model: ModelView, signals: Signals) -> str:
    if level == "High":
        lead = "This looks like a phishing email."
    elif level == "Medium":
        lead = "This email is suspicious and worth a careful second look."
    else:
        lead = "No strong signs of phishing were found."
    bits = []
    if mode != "model":
        n = len(rules.findings)
        bits.append("no rule-based warning signs" if n == 0 else
                    f"{n} rule-based warning sign{'s' if n != 1 else ''}")
    if model.available and mode != "rules":
        bits.append(f"the model rates it {model.percent}% likely phishing")
    return lead + (" (" + "; ".join(bits) + ")." if bits else "")
