"""Detect warning signs in a parsed email and keep the evidence.

This is the single place where WarnMail *looks* at an email. Both of the
checks built on top of it use the same detections:

* ``features.py`` turns them into numbers for the Random Forest model;
* ``rules.py`` turns them into plain-language findings for the user.

Keeping detection in one place means the model and the rules can never
disagree about what is actually in the email.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from warnmail import domains, indicators
from warnmail.parser import ParsedEmail, link_host

# Words that make a display name sound like an organisation or an official
# role rather than a private person.
BUSINESS_NAME_WORDS = {
    "bank", "support", "service", "services", "security", "team", "accounts",
    "account", "billing", "payroll", "helpdesk", "help", "desk", "it", "admin",
    "administrator", "administration", "hr", "finance", "director", "ceo",
    "cfo", "chief", "manager", "notification", "notifications", "alert",
    "alerts", "office", "customer", "care", "delivery", "department", "dept",
    "official", "verification", "noreply", "no-reply", "executive", "mail",
}
_DOMAIN_IN_TEXT = re.compile(r"(?:https?://)?(?:www\.)?((?:[a-z0-9-]+\.)+[a-z]{2,6})(?:[/:?#]\S*)?", re.IGNORECASE)
_EMAIL_IN_TEXT = re.compile(r"[\w.+'-]+@([\w-]+(?:\.[\w-]+)+)")


@dataclass
class LinkCheck:
    url: str
    text: str
    host: str
    domain: str
    is_ip: bool = False
    is_shortener: bool = False
    risky_tld: str = ""
    shown_domain: str = ""         # set when the visible text shows a different site
    insecure: bool = False         # plain http://
    login_words: list[str] = field(default_factory=list)
    lookalike_of: str = ""         # brand or organisation this host imitates
    deceptive: list[str] = field(default_factory=list)  # real tricks: @-host, punycode
    unusual: list[str] = field(default_factory=list)     # weak, cosmetic oddities only
    external: bool = False         # goes to a different site from the sender's
    trusted: bool = False          # goes to a known trusted service (google.com...)

    @property
    def is_risky(self) -> bool:
        # A link to a known trusted service is never "risky" - there is nowhere
        # harmful for it to lead. (A look-alike like g00gle.com is NOT trusted.)
        if self.trusted:
            return False
        # The cosmetic `unusual` oddities (a long or hyphenated URL) are
        # deliberately NOT counted as risky - too weak to escalate other rules.
        return bool(self.is_ip or self.is_shortener or self.risky_tld or self.shown_domain
                    or self.lookalike_of or self.deceptive)


@dataclass
class SenderCheck:
    has_sender: bool
    address: str = ""
    domain: str = ""
    display_name: str = ""
    display_mismatch: str = ""     # explanation when the name and address disagree
    reply_to: str = ""             # set only when replies go to a different domain
    reply_to_risky: bool = False   # reply domain is free webmail or a lookalike
    free_webmail_business_name: bool = False
    lookalike_of: str = ""


@dataclass
class AttachmentCheck:
    name: str
    risk: str = ""                 # "", "medium" or "high"
    reason: str = ""


@dataclass
class Signals:
    parsed: ParsedEmail
    phrases: dict[str, list[str]]
    subject_alarm: list[str]
    generic_greeting: str | None
    exclamations: int
    shouting_ratio: float
    body_words: int
    links: list[LinkCheck]
    sender: SenderCheck
    attachments: list[AttachmentCheck]

    @property
    def risky_links(self) -> list[LinkCheck]:
        return [link for link in self.links if link.is_risky]

    @property
    def offsite_links(self) -> list[LinkCheck]:
        """Links that leave the sender's own website (or all links if we
        don't know who the sender is). Links to trusted services are excluded -
        a link to real google.com is not an off-ramp to an attacker."""
        if not self.sender.has_sender:
            return [link for link in self.links if not link.trusted]
        return [link for link in self.links if link.external and not link.trusted]

    @property
    def lookalikes(self) -> list[str]:
        """Descriptions of every domain that imitates a protected name."""
        found = []
        if self.sender.lookalike_of:
            found.append(f"sender address {self.sender.address} imitates {self.sender.lookalike_of}")
        for link in self.links:
            if link.lookalike_of:
                found.append(f"link to {link.host} imitates {link.lookalike_of}")
        return found


def _shown_domain(text: str) -> str:
    """If the visible link text shows a web address, return its domain."""
    if not text or _EMAIL_IN_TEXT.search(text):
        return ""
    for match in _DOMAIN_IN_TEXT.finditer(text):
        host = match.group(1).lower()
        last = host.rsplit(".", 1)[-1]
        looks_like_web = match.group(0).lower().startswith(("http", "www.")) or last not in indicators.ALL_ATTACHMENT_EXTENSIONS
        if looks_like_web and last.isalpha():
            return domains.registered_domain(host)
    return ""


def check_link(url: str, text: str, sender_domain: str, protected) -> LinkCheck:
    host = link_host(url)
    reg = domains.registered_domain(host)
    check = LinkCheck(url=url, text=text, host=host, domain=reg)
    check.is_ip = domains.is_ip_address(host)
    check.is_shortener = reg in domains.URL_SHORTENERS
    tld = domains.tld(host)
    check.risky_tld = tld if tld in domains.RISKY_TLDS else ""
    shown = _shown_domain(text)
    if shown and shown != reg:
        check.shown_domain = shown
    check.trusted = domains.is_trusted_domain(host)
    check.insecure = url.lower().startswith("http://")
    lowered = url.lower()
    check.login_words = [word for word in domains.LOGIN_URL_WORDS if word in lowered]
    brand = domains.find_lookalike(host, protected)
    check.lookalike_of = brand.label if brand else ""

    authority = re.sub(r"^[a-z]+://", "", lowered).split("/", 1)[0]
    # Genuine deception tricks: worth keeping as real warning signs.
    if "@" in authority:
        check.deceptive.append("contains an @ sign that hides the real address")
    if "xn--" in host:
        check.deceptive.append("uses look-alike foreign characters (punycode)")
    # Cosmetic oddities: weak on their own (many genuine links look like this),
    # so they only ever add a tiny "note" to the score (see rules.py).
    if domains.subdomain_depth(host) >= 3:
        check.unusual.append("has an unusually long chain of sub-domains")
    if host.count("-") >= 3:
        check.unusual.append("has many hyphens in the address")
    if len(url) > 120:
        check.unusual.append("is unusually long")
    if re.search(r":\d{2,5}$", authority.split("@")[-1]) and not check.is_ip:
        check.unusual.append("uses an unusual port number")
    check.external = bool(sender_domain) and reg != sender_domain
    return check


def check_sender(parsed: ParsedEmail, protected) -> SenderCheck:
    if not parsed.has_sender:
        return SenderCheck(has_sender=False, display_name=parsed.from_name)

    check = SenderCheck(has_sender=True, address=parsed.from_address,
                        domain=parsed.from_domain, display_name=parsed.from_name)
    name = parsed.from_name or ""
    name_lower = name.lower()

    # 1. The display name contains a different email address.
    email_in_name = _EMAIL_IN_TEXT.search(name)
    if email_in_name:
        shown = domains.registered_domain(email_in_name.group(1))
        if shown and shown != check.domain:
            check.display_mismatch = (
                f"The sender's name shows '{email_in_name.group(0)}', but the email "
                f"actually came from '{check.address}'.")

    # 2. The display name claims to be a known organisation.
    if not check.display_mismatch:
        squashed_name = domains.deconfuse(re.sub(r"[^a-z0-9]", "", name_lower))
        for item in protected:
            if item.token in squashed_name and check.domain not in item.domains:
                check.display_mismatch = (
                    f"The sender calls itself '{name}', but the email came from "
                    f"'{check.domain}', which is not {item.label}'s real address.")
                break

    # 3. Reply-To goes somewhere else.
    if parsed.reply_to and parsed.reply_to_domain and parsed.reply_to_domain != check.domain:
        check.reply_to = parsed.reply_to
        reply_host = domains.host_from_address(parsed.reply_to)
        check.reply_to_risky = (domains.is_free_webmail(reply_host)
                                or domains.find_lookalike(reply_host, protected) is not None)

    # 4. Official-sounding name sent from a free webmail account.
    if domains.is_free_webmail(check.domain):
        words = set(re.findall(r"[a-z]+(?:-[a-z]+)?", name_lower))
        mentions_brand = any(item.token in name_lower.replace(" ", "") for item in protected)
        check.free_webmail_business_name = bool(words & BUSINESS_NAME_WORDS) or mentions_brand

    # 5. The sender's own domain imitates a brand or your organisation.
    brand = domains.find_lookalike(parsed.from_host, protected)
    check.lookalike_of = brand.label if brand else ""
    return check


def check_attachment(name: str) -> AttachmentCheck:
    lower = name.lower().strip()
    pieces = [piece.strip() for piece in lower.rsplit(".", 2)]
    ext = pieces[-1] if len(pieces) > 1 else ""
    check = AttachmentCheck(name=name)
    dangerous = (indicators.EXECUTABLE_EXTENSIONS | indicators.DISK_IMAGE_EXTENSIONS
                 | indicators.WEB_PAGE_EXTENSIONS | indicators.MACRO_EXTENSIONS
                 | indicators.ARCHIVE_EXTENSIONS)
    if len(pieces) == 3 and pieces[1] in indicators.DOCUMENT_EXTENSIONS and ext in dangerous:
        check.risk, check.reason = "high", (
            f"it is named like a .{pieces[1]} document but is really a .{ext} file")
    elif ext in indicators.EXECUTABLE_EXTENSIONS:
        check.risk, check.reason = "high", "it is a program or script that can run code on your computer"
    elif ext in indicators.DISK_IMAGE_EXTENSIONS:
        check.risk, check.reason = "high", "disk-image files are a common way to sneak malware past filters"
    elif ext in indicators.WEB_PAGE_EXTENSIONS:
        check.risk, check.reason = "high", "web-page attachments are often used to show a fake sign-in page"
    elif ext in indicators.MACRO_EXTENSIONS:
        check.risk, check.reason = "high", "it is an Office file with macros, which can run hidden code"
    elif ext in indicators.ARCHIVE_EXTENSIONS:
        check.risk, check.reason = "medium", "compressed archives can hide dangerous files inside"
    return check


def detect(parsed: ParsedEmail) -> Signals:
    """Run every detection on a parsed email."""
    protected = domains.protected_names(parsed.recipient_domain)
    text = f"{parsed.subject}\n{parsed.body}"

    phrases = {name: indicators.find_phrases(text, patterns)
               for name, patterns in indicators.CATEGORIES.items()}
    subject_alarm = indicators.find_phrases(
        parsed.subject, indicators.URGENCY + indicators.THREAT + indicators.CREDENTIAL)

    words = re.findall(r"[A-Za-z]+", text)
    shouting = [word for word in words if len(word) >= 4 and word.isupper()]
    shouting_ratio = len(shouting) / len(words) if words else 0.0   # avoid divide-by-zero

    sender = check_sender(parsed, protected)
    links = [check_link(link.url, link.text, sender.domain, protected) for link in parsed.links]
    attachments = [check_attachment(name) for name in parsed.attachments]

    return Signals(
        parsed=parsed,
        phrases=phrases,
        subject_alarm=subject_alarm,
        generic_greeting=indicators.find_generic_greeting(parsed.body),
        exclamations=min(text.count("!"), 10),
        shouting_ratio=round(shouting_ratio, 4),
        body_words=len(parsed.body.split()),
        links=links,
        sender=sender,
        attachments=attachments,
    )
