"""Central settings for WarnMail.

Everything you are likely to want to tweak (file locations, how the rule
score and model score are blended, where the Low/Medium/High boundaries sit)
lives here, so you can experiment without hunting through the code.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

from warnmail import __version__

APP_NAME = "WarnMail"
APP_VERSION = __version__


def bundle_root() -> Path:
    """Return the folder that holds WarnMail's bundled files.

    * Running from source: the project folder (the one containing ``models/``).
    * Running as a PyInstaller .exe: PyInstaller unpacks bundled files into a
      temporary folder and stores its path in ``sys._MEIPASS``.

    Every file the app needs at runtime (the model, the demo samples, the
    icon) must be found through this function, otherwise the packaged .exe
    will look in the wrong place.
    """
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS)
    return Path(__file__).resolve().parent.parent


def user_data_dir() -> Path:
    """Folder for WarnMail's own log file (never contains email content)."""
    if sys.platform.startswith("win"):
        base = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
    else:
        base = Path(os.environ.get("XDG_STATE_HOME", Path.home() / ".local" / "state"))
    return base / APP_NAME


ROOT = bundle_root()
MODEL_PATH = ROOT / "models" / "warnmail_rf.joblib"
SAMPLES_DIR = ROOT / "data" / "samples"
ASSETS_DIR = ROOT / "assets"

# ---------------------------------------------------------------------------
# Rule engine: every warning sign adds points according to its severity.
# The total is capped at 100. Example: one "high" sign alone = 35 (Medium),
# two "high" signs = 70 (High).
# ---------------------------------------------------------------------------
# "note" is a very weak consideration (a long or oddly built URL, say): still
# shown to the user, but worth only a couple of points so it can't push a
# benign email toward a warning on its own.
SEVERITY_POINTS = {"note": 3, "low": 10, "medium": 20, "high": 35}
MAX_RULE_SCORE = 100

# ---------------------------------------------------------------------------
# Hybrid blend: combined score = MODEL_WEIGHT * (model probability x 100)
#                              + RULES_WEIGHT * rule score
# The weights must add up to 1.0.
# ---------------------------------------------------------------------------
MODEL_WEIGHT = 0.6
RULES_WEIGHT = 0.4

# ---------------------------------------------------------------------------
# Risk levels. The same 0-100 boundaries are used in every mode:
#   score <  MEDIUM_THRESHOLD                -> Low
#   MEDIUM_THRESHOLD <= score < HIGH_THRESHOLD -> Medium
#   score >= HIGH_THRESHOLD                  -> High
# An email rated Medium or High counts as "flagged" in the evaluation.
# ---------------------------------------------------------------------------
MEDIUM_THRESHOLD = 35
HIGH_THRESHOLD = 65

# Safety overrides used by the rules and hybrid modes. Strong, specific
# warning signs (a disguised link, a gift-card request...) should never be
# averaged away by the model, so:
#   * 1 or more high-severity findings  -> at least Medium
#   * 2 or more high-severity findings  -> High
HIGH_FINDINGS_FOR_MEDIUM = 1
HIGH_FINDINGS_FOR_HIGH = 2

# When the two checks disagree this much (in points out of 100), the report
# adds a note telling the user to be extra careful.
DISAGREEMENT_GAP = 50
