"""Train WarnMail's Random Forest and save it as a model bundle.

Run it with::

    python -m training.train_model

What it does, in order:

1. Load (or generate) the synthetic dataset.
2. Turn every email into features.
3. Split into train and test **by template group**, so no template appears on
   both sides (see ``training/dataset.py`` for why this matters).
4. Tune a few Random Forest settings with grouped cross-validation.
5. Train the final model on the training groups and measure it on the unseen
   test groups.
6. Save the model, the feature names and the scores to
   ``models/warnmail_rf.joblib``.
7. Print a short "data leakage" demonstration: the same model evaluated with a
   naive random split reports much higher (misleading) numbers.

The goal is an honest, modest model, plus code that shows *how* it was kept
honest - not a headline accuracy figure.
"""

from __future__ import annotations

import argparse
import platform
from datetime import date
from pathlib import Path

import numpy as np

from warnmail.model import ModelBundle, save_bundle
from training.dataset import DATA_DIR, generate, load_jsonl, write_jsonl
from training.evaluate import metrics_at, summarise_confusion
from training.featurise import build_matrix

MODEL_PATH = Path(__file__).resolve().parent.parent / "models" / "warnmail_rf.joblib"


def load_or_make_dataset(path: Path, seed: int):
    if path.exists():
        return load_jsonl(path)
    examples = generate(seed=seed)
    write_jsonl(examples, path)
    return examples


def grouped_oof_predictions(estimator, X, y, groups, seed: int, n_splits: int = 6):
    """Honest predictions for every email, via grouped cross-validation.

    With only a dozen template groups, holding out a single test fold is too
    noisy: whichever few groups land in it dominate the score. Instead we run
    grouped k-fold cross-validation and, for each email, keep the prediction
    made by the fold in which its group was held out. Every email is therefore
    scored by a model that never saw its template, and every group gets a turn
    in the test set. This is the standard way to get a stable estimate from a
    small dataset.
    """
    from sklearn.base import clone
    from sklearn.model_selection import StratifiedGroupKFold

    n_splits = min(n_splits, len(set(groups)))
    splitter = StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    oof_proba = np.full(len(y), np.nan)
    for train_idx, test_idx in splitter.split(X, y, groups):
        fitted = clone(estimator).fit(X[train_idx], y[train_idx])
        col = list(fitted.classes_).index(1)
        oof_proba[test_idx] = fitted.predict_proba(X[test_idx])[:, col]
    assert not np.isnan(oof_proba).any(), "some emails were never in a test fold"
    return oof_proba


def tune(X, y, groups, seed: int):
    """Grid-search a few settings with grouped cross-validation.

    Small trees and a cap on depth are preferred on purpose: with little data
    a deep forest just memorises it. ``class_weight='balanced'`` stops the
    model ignoring the smaller class.
    """
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.model_selection import GridSearchCV, StratifiedGroupKFold

    grid = {
        "n_estimators": [200, 400],
        "max_depth": [4, 6, 8, None],
        "min_samples_leaf": [1, 2, 3],
        "max_features": ["sqrt", 0.5],
    }
    base = RandomForestClassifier(random_state=seed, class_weight="balanced", n_jobs=-1)
    cv = StratifiedGroupKFold(n_splits=4, shuffle=True, random_state=seed)
    search = GridSearchCV(base, grid, scoring="f1", cv=cv, n_jobs=-1)
    search.fit(X, y, groups=groups)
    return search.best_estimator_, search.best_params_, float(search.best_score_)


def leakage_demo(X, y, groups, params, seed: int) -> dict:
    """Show the gap between an honest split and a leaky one.

    Same settings, two evaluations:
      * grouped: whole templates held out (honest)
      * random:  rows shuffled, ignoring groups (leaky - variants of a
        template end up in both train and test)
    The leaky split reports a much higher score. That gap is the lesson.
    """
    from sklearn.base import clone
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.model_selection import StratifiedGroupKFold, StratifiedKFold

    model = RandomForestClassifier(random_state=seed, class_weight="balanced",
                                   n_jobs=-1, **params)

    def cross_val_f1(splits) -> float:
        scores = []
        for train_idx, test_idx in splits:
            fitted = clone(model).fit(X[train_idx], y[train_idx])
            scores.append(metrics_at(y[test_idx], fitted.predict(X[test_idx]))["f1"])
        return float(np.mean(scores))

    grouped = StratifiedGroupKFold(n_splits=4, shuffle=True, random_state=seed)
    random = StratifiedKFold(n_splits=4, shuffle=True, random_state=seed)
    return {
        "grouped_f1": round(cross_val_f1(grouped.split(X, y, groups)), 3),
        "leaky_f1": round(cross_val_f1(random.split(X, y)), 3),
    }


def train(seed: int = 7, dataset_path: Path | None = None, out_path: Path | None = None):
    dataset_path = dataset_path or (DATA_DIR / "dataset.jsonl")
    out_path = out_path or MODEL_PATH
    examples = load_or_make_dataset(dataset_path, seed)
    X, y, groups, names = build_matrix(examples)

    print(f"Dataset: {len(y)} emails, {int(y.sum())} phishing / {int((1 - y).sum())} legitimate, "
          f"{len(set(groups))} template groups.")

    best, params, cv_f1 = tune(X, y, groups, seed)
    print(f"Best settings (grouped CV f1={cv_f1:.3f}): {params}")

    # Honest performance: cross-validated predictions where every email is
    # scored by a model that never saw its template group.
    oof_proba = grouped_oof_predictions(best, X, y, groups, seed)
    oof_pred = (oof_proba >= 0.5).astype(int)
    cv_metrics = metrics_at(y, oof_pred)
    confusion = summarise_confusion(y, oof_pred)
    print(f"Grouped cross-validation (model alone, honest): precision "
          f"{cv_metrics['precision']:.2f}, recall {cv_metrics['recall']:.2f}, "
          f"f1 {cv_metrics['f1']:.2f}, accuracy {cv_metrics['accuracy']:.2f}")

    leak = leakage_demo(X, y, groups, params, seed)
    print(f"Leakage check: honest grouped f1={leak['grouped_f1']}  vs  "
          f"leaky random-split f1={leak['leaky_f1']}  (random-split looks better, "
          f"but it is fooling itself)")

    # The shipped model is refit on all of the data; the honest scores above
    # (never trained on what they test) are the ones we report.
    final = best.__class__(**best.get_params())
    final.fit(X, y)

    metadata = {
        "trained_on": str(date.today()),
        "n_examples": int(len(y)),
        "n_phishing": int(y.sum()),
        "n_groups": int(len(set(groups))),
        "params": params,
        "cv_f1": round(cv_f1, 3),
        "cv_method": "grouped 6-fold cross-validation (out-of-fold predictions)",
        "cv_metrics": {k: round(v, 3) for k, v in cv_metrics.items()},
        "cv_confusion": confusion,
        "leakage_demo": leak,
        "feature_names": names,
        "python": platform.python_version(),
        "libraries": _library_versions(),
    }
    bundle = ModelBundle(model=final, feature_names=names, metadata=metadata)
    save_bundle(bundle, out_path)
    print(f"\nSaved model to {out_path}")
    print("NOTE: the honest held-out scores above are the ones to quote, not the "
          "leaky split and not accuracy on the training data.")
    return bundle, metadata


def _library_versions() -> dict:
    import sklearn
    versions = {"scikit-learn": sklearn.__version__, "numpy": np.__version__}
    try:
        import scipy
        versions["scipy"] = scipy.__version__
    except Exception:
        pass
    return versions


def main() -> None:
    parser = argparse.ArgumentParser(description="Train WarnMail's Random Forest.")
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--dataset", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=None)
    args = parser.parse_args()
    train(seed=args.seed, dataset_path=args.dataset, out_path=args.out)


if __name__ == "__main__":
    main()
