"""Shared evaluation helpers and the mode-comparison report.

Two jobs:

* small metric helpers (``metrics_at``, ``summarise_confusion``) used by
  training and by the report;
* ``compare_modes`` / ``main``: run the three analyzer modes (rules, model,
  hybrid) over the whole dataset and show how they compare, including which
  emails each one gets wrong.

Run ``python -m training.evaluate`` after training to produce
``training/reports/evaluation.md``.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

REPORTS_DIR = Path(__file__).resolve().parent / "reports"


def metrics_at(y_true, y_pred) -> dict:
    """Precision, recall, f1 and accuracy for label 1 (phishing)."""
    y_true = np.asarray(y_true).astype(int)
    y_pred = np.asarray(y_pred).astype(int)
    tp = int(np.sum((y_pred == 1) & (y_true == 1)))
    fp = int(np.sum((y_pred == 1) & (y_true == 0)))
    fn = int(np.sum((y_pred == 0) & (y_true == 1)))
    tn = int(np.sum((y_pred == 0) & (y_true == 0)))
    precision = tp / (tp + fp) if (tp + fp) else 0.0
    recall = tp / (tp + fn) if (tp + fn) else 0.0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0.0
    accuracy = (tp + tn) / len(y_true) if len(y_true) else 0.0
    return {"precision": precision, "recall": recall, "f1": f1, "accuracy": accuracy,
            "tp": tp, "fp": fp, "fn": fn, "tn": tn}


def summarise_confusion(y_true, y_pred) -> dict:
    m = metrics_at(y_true, y_pred)
    return {"true_phishing_caught": m["tp"], "phishing_missed": m["fn"],
            "legit_flagged": m["fp"], "legit_cleared": m["tn"]}


def confusion_block(title: str, m: dict) -> list[str]:
    return [
        f"**{title}**", "",
        "| | predicted phishing | predicted legitimate |",
        "| --- | --- | --- |",
        f"| actually phishing | {m['tp']} (caught) | {m['fn']} (missed) |",
        f"| actually legitimate | {m['fp']} (false alarm) | {m['tn']} (cleared) |",
        "",
    ]


def compare_modes(model_path: Path | None = None, seed: int = 7) -> dict:
    """Score rules-only, model-only and hybrid - honestly - on every email.

    The rules never learn, so they can be run over the whole dataset directly.
    The model (and therefore the hybrid) must not be tested on emails it was
    trained on, or the comparison is meaningless. So we cross-validate by
    template group: for each fold we train a fresh model on the training
    groups and analyse the held-out groups with an Analyzer backed by that
    fold's model. Every email is thus analysed by a model that never saw its
    template. (The model WarnMail ships is a separate, final one trained on
    all the data; this evaluation only measures how the approach generalises.)
    """
    import numpy as np
    from sklearn.base import clone
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.model_selection import StratifiedGroupKFold

    from warnmail.analyzer import Analyzer
    from warnmail.model import ModelBundle, load_bundle
    from warnmail.features import FEATURE_NAMES
    from training.dataset import DATA_DIR, generate, load_jsonl
    from training.featurise import build_matrix

    dataset_path = DATA_DIR / "dataset.jsonl"
    examples = load_jsonl(dataset_path) if dataset_path.exists() else generate()
    X, y, groups, names = build_matrix(examples)

    # Reuse the shipped model's tuned settings, so we compare like with like.
    shipped = load_bundle(model_path) if model_path else load_bundle(
        Path(__file__).resolve().parent.parent / "models" / "warnmail_rf.joblib")
    params = shipped.metadata.get("params", {})
    template = RandomForestClassifier(random_state=seed, class_weight="balanced",
                                      n_jobs=-1, **params)

    # Build an Analyzer (fold model) for each email, via grouped CV.
    analyzers: list[Analyzer] = [None] * len(examples)
    n_splits = min(6, len(set(groups)))
    splitter = StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    for train_idx, test_idx in splitter.split(X, y, groups):
        fold_model = clone(template).fit(X[train_idx], y[train_idx])
        bundle = ModelBundle(model=fold_model, feature_names=list(FEATURE_NAMES),
                             metadata={"fold": True})
        fold_analyzer = Analyzer(bundle=bundle)
        for i in test_idx:
            analyzers[i] = fold_analyzer

    results = {}
    per_email = []
    for mode in ("rules", "model", "hybrid"):
        y_true, y_pred = [], []
        mistakes = {"false_positive": [], "false_negative": []}
        for example, analyzer in zip(examples, analyzers):
            result = analyzer.analyze(example.text, mode=mode)
            predicted = 1 if result.is_flagged else 0
            y_true.append(example.label)
            y_pred.append(predicted)
            if predicted == 1 and example.label == 0:
                mistakes["false_positive"].append(example)
            elif predicted == 0 and example.label == 1:
                mistakes["false_negative"].append(example)
            if mode == "hybrid":
                per_email.append((example, result))
        results[mode] = {"metrics": metrics_at(y_true, y_pred), "mistakes": mistakes}
    return {"results": results, "n": len(examples), "per_email": per_email}


def build_report(data: dict) -> str:
    results = data["results"]
    lines = ["# WarnMail: comparing the three modes", "",
             f"Evaluated on all **{data['n']}** synthetic emails. An email counts as "
             "\"flagged\" when its risk level is Medium or High.", "",
             "A quick reminder on the numbers: **recall** is the share of real phishing "
             "that gets caught, **precision** is the share of flagged emails that really "
             "were phishing, and **f1** balances the two.", "",
             "## Scores", "",
             "| Mode | Precision | Recall | F1 | Accuracy | False alarms | Missed phishing |",
             "| --- | --- | --- | --- | --- | --- | --- |"]
    for mode in ("rules", "model", "hybrid"):
        m = results[mode]["metrics"]
        lines.append(f"| {mode} | {m['precision']:.2f} | {m['recall']:.2f} | {m['f1']:.2f} | "
                     f"{m['accuracy']:.2f} | {m['fp']} | {m['fn']} |")
    lines.append("")

    for mode in ("rules", "model", "hybrid"):
        lines += confusion_block(f"Confusion matrix - {mode}", results[mode]["metrics"])

    lines += ["## What each mode gets wrong", ""]
    for mode in ("rules", "model", "hybrid"):
        mistakes = results[mode]["mistakes"]
        lines.append(f"**{mode}** - {len(mistakes['false_negative'])} missed, "
                     f"{len(mistakes['false_positive'])} false alarms")
        for example in mistakes["false_negative"][:4]:
            lines.append(f"  - missed: {example.category} ({example.note or 'no note'})")
        for example in mistakes["false_positive"][:4]:
            lines.append(f"  - false alarm: {example.category} ({example.note or 'no note'})")
        lines.append("")

    rules_m = results["rules"]["metrics"]
    model_m = results["model"]["metrics"]
    lines += ["## How to read this", "",
              f"The rules score almost perfectly here (precision {rules_m['precision']:.2f}, "
              f"recall {rules_m['recall']:.2f}), and that is a trap worth understanding. "
              "The synthetic emails were built from templates that contain the very signals "
              "the rules look for (disguised links, gift-card requests, 'bank details "
              "changed', and so on). So the rules are being tested on the patterns they "
              "were written to catch. They cannot really lose on this data.", "",
              "**Real phishing will use patterns you did not hand-code.** That is exactly "
              "where a hand-written rule list falls down and where a model earns its place: "
              "it can pick up on combinations of features you never wrote a rule for. This "
              "dataset cannot show that strength, because we wrote both the rules and the "
              "data from the same idea of what phishing looks like.", "",
              f"The model-alone column is the honest one to study. At f1 {model_m['f1']:.2f} "
              "it is clearly weaker here, and its mistakes are telling: it tends to **miss** "
              "the quiet phishing (the calm bank-change email, the malware attachment whose "
              "danger is the file type rather than the words) and to **false-alarm** on "
              "genuine-but-urgent emails (a real overdue invoice). The rules catch the first "
              "group through specific high-severity checks; the model would help most on "
              "novel wording the rules miss.", "",
              "The practical lesson for the real project: (1) do not trust a near-perfect "
              "rule score on data you generated yourself; (2) gather realistic emails, "
              "including hard ones, so the model has something to generalise from; and "
              "(3) keep the hybrid's safety overrides, so one strong, specific sign is never "
              "averaged away by a model that is only mildly suspicious.", "",
              "_Scores on synthetic data are optimistic. Treat them as a way to compare "
              "the three modes, not as a measure of real-world performance._"]
    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser(description="Compare WarnMail's three modes.")
    parser.add_argument("--model", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=REPORTS_DIR / "evaluation.md")
    args = parser.parse_args()

    data = compare_modes(model_path=args.model)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(build_report(data), encoding="utf-8")
    for mode in ("rules", "model", "hybrid"):
        m = data["results"][mode]["metrics"]
        print(f"{mode:>7}: precision {m['precision']:.2f}  recall {m['recall']:.2f}  "
              f"f1 {m['f1']:.2f}  (false alarms {m['fp']}, missed {m['fn']})")
    print(f"\nFull report: {args.out}")


if __name__ == "__main__":
    main()
