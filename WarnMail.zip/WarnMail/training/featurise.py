"""Turn the dataset's email text into the model's feature table.

Kept separate from training so the exact same path - parse, detect signals,
extract features - is used for the dataset, inside the app, and in the tests.
If featurisation ever drifted between training and the app, the model would
quietly misbehave, so there is only one copy of it.
"""

from __future__ import annotations

import numpy as np

from warnmail.features import FEATURE_NAMES, extract_features, to_vector
from warnmail.parser import parse_email
from warnmail.signals import detect
from training.dataset import Example


def featurise_text(text: str) -> dict[str, float]:
    return extract_features(detect(parse_email(text)))


def build_matrix(examples: list[Example]):
    """Return (X, y, groups) as numpy arrays, plus the feature-name list."""
    rows, labels, groups = [], [], []
    for example in examples:
        features = featurise_text(example.text)
        rows.append(to_vector(features))
        labels.append(example.label)
        groups.append(example.group)
    X = np.array(rows, dtype=float)
    y = np.array(labels, dtype=int)
    return X, y, np.array(groups), list(FEATURE_NAMES)
