# WarnMail: comparing the three modes

Evaluated on all **144** synthetic emails. An email counts as "flagged" when its risk level is Medium or High.

A quick reminder on the numbers: **recall** is the share of real phishing that gets caught, **precision** is the share of flagged emails that really were phishing, and **f1** balances the two.

## Scores

| Mode | Precision | Recall | F1 | Accuracy | False alarms | Missed phishing |
| --- | --- | --- | --- | --- | --- | --- |
| rules | 1.00 | 1.00 | 1.00 | 1.00 | 0 | 0 |
| model | 0.68 | 0.61 | 0.64 | 0.61 | 24 | 32 |
| hybrid | 1.00 | 1.00 | 1.00 | 1.00 | 0 | 0 |

**Confusion matrix - rules**

| | predicted phishing | predicted legitimate |
| --- | --- | --- |
| actually phishing | 82 (caught) | 0 (missed) |
| actually legitimate | 0 (false alarm) | 62 (cleared) |

**Confusion matrix - model**

| | predicted phishing | predicted legitimate |
| --- | --- | --- |
| actually phishing | 50 (caught) | 32 (missed) |
| actually legitimate | 24 (false alarm) | 38 (cleared) |

**Confusion matrix - hybrid**

| | predicted phishing | predicted legitimate |
| --- | --- | --- |
| actually phishing | 82 (caught) | 0 (missed) |
| actually legitimate | 0 (false alarm) | 62 (cleared) |

## What each mode gets wrong

**rules** - 0 missed, 0 false alarms

**model** - 32 missed, 24 false alarms
  - missed: phishing: malware attachment (no note)
  - missed: phishing: bank-change (BEC) (hard: calm, no links)
  - missed: phishing: malware attachment (no note)
  - missed: phishing: malware attachment (no note)
  - false alarm: legitimate overdue reminder (hard: urgent but genuine)
  - false alarm: legitimate internal note (no note)
  - false alarm: legitimate internal note (no note)
  - false alarm: legitimate overdue reminder (hard: urgent but genuine)

**hybrid** - 0 missed, 0 false alarms

## How to read this

The rules score almost perfectly here (precision 1.00, recall 1.00), and that is a trap worth understanding. The synthetic emails were built from templates that contain the very signals the rules look for (disguised links, gift-card requests, 'bank details changed', and so on). So the rules are being tested on the patterns they were written to catch. They cannot really lose on this data.

**Real phishing will use patterns you did not hand-code.** That is exactly where a hand-written rule list falls down and where a model earns its place: it can pick up on combinations of features you never wrote a rule for. This dataset cannot show that strength, because we wrote both the rules and the data from the same idea of what phishing looks like.

The model-alone column is the honest one to study. At f1 0.64 it is clearly weaker here, and its mistakes are telling: it tends to **miss** the quiet phishing (the calm bank-change email, the malware attachment whose danger is the file type rather than the words) and to **false-alarm** on genuine-but-urgent emails (a real overdue invoice). The rules catch the first group through specific high-severity checks; the model would help most on novel wording the rules miss.

The practical lesson for the real project: (1) do not trust a near-perfect rule score on data you generated yourself; (2) gather realistic emails, including hard ones, so the model has something to generalise from; and (3) keep the hybrid's safety overrides, so one strong, specific sign is never averaged away by a model that is only mildly suspicious.

_Scores on synthetic data are optimistic. Treat them as a way to compare the three modes, not as a measure of real-world performance._
