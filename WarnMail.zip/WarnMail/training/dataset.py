"""Generate a synthetic, labelled email dataset for training and testing.

Why synthetic data? Real phishing emails cannot be shared freely and come
tangled with personal information. For a learning project it is cleaner to
*generate* examples from templates so we control exactly what signals each
one contains and can label them with confidence.

Three ideas make this dataset useful rather than a toy:

1. **Template groups.** Every email records the template it came from
   (``group``). All the variations of one template share a group id, so the
   training/test split can keep a whole template on one side of the split.
   Without this, near-identical emails land in both sets and the model looks
   far better than it is (the classic "data leakage" trap, and the first
   thing a new Random Forest user should learn to check).

2. **Hard cases on purpose.** The dataset deliberately includes
   *legitimate* emails that look a bit alarming (a real overdue invoice, a
   genuine password-reset) and *phishing* emails that look calm. A model
   that only ever sees cartoonish phishing learns nothing useful.

3. **Fictional brands only.** Every organisation here is invented (see
   ``warnmail.domains.KNOWN_BRANDS``). The language is intentionally generic:
   it is enough to teach the detector the shape of a scam without being a
   ready-to-use template for a real one.

Run ``python -m training.dataset`` to write ``data/dataset.jsonl`` and a
dataset card describing what was produced.
"""

from __future__ import annotations

import argparse
import json
import random
from dataclasses import asdict, dataclass, field
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = PROJECT_ROOT / "data"

# Fictional people, companies and the invented brands' real domains.
RECIPIENTS = [
    ("Priya Nguyen", "priya.nguyen@riverbendaccounting.com.au", "riverbendaccounting.com.au"),
    ("Tom Fletcher", "tom@fletcherbuilding.com.au", "fletcherbuilding.com.au"),
    ("Aisha Rahman", "a.rahman@claybrookdental.com.au", "claybrookdental.com.au"),
    ("Dan Oakley", "dan.oakley@summitfitness.com.au", "summitfitness.com.au"),
    ("Mei Lin", "mei@greenfieldgrocers.com.au", "greenfieldgrocers.com.au"),
    ("Jack Peters", "jack.peters@harbourlinebank.com.au", "harbourlinebank.com.au"),
]
FIRST_NAMES = ["Sam", "Alex", "Jordan", "Riley", "Casey", "Morgan", "Lee", "Nat", "Kim", "Drew"]
COLLEAGUES = ["Rebecca Shaw", "David Lowe", "Hannah Blake", "Michael Tran", "Sophie Reed"]


@dataclass
class Example:
    text: str
    label: int                 # 1 = phishing, 0 = legitimate
    group: str                 # template id; variants share it (leakage-safe splits)
    category: str              # human-readable kind of email
    note: str = ""             # why it is interesting (e.g. "hard legitimate")
    tags: list[str] = field(default_factory=list)


def _pick(rng, items):
    return items[rng.randrange(len(items))]


# ---------------------------------------------------------------------------
# Builders. Each returns one email body given a random generator and a
# recipient. Placeholders are filled so variations differ in wording and
# detail but keep the same underlying pattern (hence a shared group id).
# ---------------------------------------------------------------------------

def _legit_invoice(rng, who) -> tuple[str, str]:
    name, _, _ = who
    first = name.split()[0]
    supplier = _pick(rng, [("Bayside Office Supplies", "baysideoffice.com.au", "INV"),
                           ("Northgate Timber", "northgatetimber.com.au", "NT"),
                           ("ClearWater Plumbing", "clearwaterplumbing.com.au", "CW")])
    num = rng.randint(1000, 99999)
    amount = f"${rng.randint(80, 4200)}.{rng.randrange(0, 100):02d}"
    day = rng.randint(1, 28)
    subject = f"Invoice {supplier[2]}-{num} from {supplier[0]}"
    body = (f"Hi {first},\n\n"
            f"Please find attached invoice {supplier[2]}-{num} for {amount} for your recent order. "
            f"Payment is due by {day} November on our usual 14-day terms.\n\n"
            f"Let me know if you have any questions.\n\n"
            f"Kind regards,\n{_pick(rng, COLLEAGUES)}\n{supplier[0]}\n"
            f"accounts@{supplier[1]} | (02) 5550 {rng.randint(1000, 9999)}")
    header = (f"From: {supplier[0]} <accounts@{supplier[1]}>\n"
              f"To: {name} <{who[1]}>\nSubject: {subject}\n"
              f"Attachments: {supplier[2]}-{num}.pdf\n\n")
    return header + body, subject


def _legit_newsletter(rng, who) -> tuple[str, str]:
    name, _, _ = who
    brand = _pick(rng, [("BrightMart", "brightmart.com.au"), ("SummitFitness", "summitfitness.com.au")])
    subject = _pick(rng, ["This week's picks", "Your November update", "What's new in store"])
    body = (f"Hi {name.split()[0]},\n\n"
            f"Here's what's new this month. We've refreshed our range and added a few new "
            f"favourites. Browse at your leisure - no rush.\n\n"
            f"You can update your preferences any time from your account page at "
            f"https://www.{brand[1]}/account.\n\n"
            f"Cheers,\nThe {brand[0]} team")
    header = (f"From: {brand[0]} <news@{brand[1]}>\nTo: {who[1]}\nSubject: {subject}\n\n")
    return header + body, subject


def _legit_reset(rng, who) -> tuple[str, str]:
    """A genuine password reset the user DID ask for - a classic hard case."""
    name, _, _ = who
    brand = _pick(rng, [("CloudNest", "cloudnest.com"), ("WorkHub 365", "workhub365.com"),
                        ("SignFlow", "signflow.com")])
    subject = f"Reset your {brand[0]} password"
    body = (f"Hi {name.split()[0]},\n\n"
            f"We received a request to reset the password for your {brand[0]} account. "
            f"If this was you, you can set a new password here:\n"
            f"https://account.{brand[1]}/reset\n\n"
            f"If you didn't request this, you can safely ignore this email and your "
            f"password will stay the same.\n\n"
            f"Thanks,\nThe {brand[0]} team")
    header = (f"From: {brand[0]} <no-reply@{brand[1]}>\nTo: {who[1]}\nSubject: {subject}\n\n")
    return header + body, subject


def _legit_overdue(rng, who) -> tuple[str, str]:
    """A real overdue-invoice reminder: urgent wording, but genuine."""
    name, _, _ = who
    num = rng.randint(1000, 9999)
    subject = f"Reminder: invoice {num} is now overdue"
    body = (f"Hi {name.split()[0]},\n\n"
            f"Our records show invoice {num} was due last week and is now overdue. "
            f"Could you please arrange payment when you get a chance? The usual bank "
            f"details are on the invoice we sent on 2 October.\n\n"
            f"If you've already paid, thank you - please ignore this reminder.\n\n"
            f"Best,\n{_pick(rng, COLLEAGUES)}\nGumleaf Energy\nbilling@gumleafenergy.com.au")
    header = (f"From: Gumleaf Energy <billing@gumleafenergy.com.au>\nTo: {who[1]}\n"
              f"Subject: {subject}\n\n")
    return header + body, subject


def _legit_internal(rng, who) -> tuple[str, str]:
    name, _, dom = who
    colleague = _pick(rng, COLLEAGUES)
    cfirst = colleague.split()[0].lower()
    subject = _pick(rng, ["Team lunch Friday", "Notes from today's meeting", "Roster for next week"])
    body = (f"Hi {name.split()[0]},\n\n"
            f"Just a quick note - {_pick(rng, ['can you send me the figures when you have a sec', 'the roster for next week is attached', 'thanks for sorting that out today'])}. "
            f"No rush.\n\nCheers,\n{colleague}")
    header = (f"From: {colleague} <{cfirst}@{dom}>\nTo: {who[1]}\nSubject: {subject}\n\n")
    return header + body, subject


def _phish_brand_credential(rng, who) -> tuple[str, str]:
    """Impersonate a brand and push a sign-in link. Deliberately generic."""
    name, _, _ = who
    brand = _pick(rng, [("Harbourline Bank", "harbourline"), ("CloudNest", "cloudnest"),
                        ("WorkHub 365", "workhub"), ("PayRoo", "payroo")])
    bad = _pick(rng, [f"{brand[1]}-secure.top", f"{brand[1]}-verify.xyz",
                     f"secure-{brand[1]}.click", f"{brand[1]}.account-update.live"])
    threat = _pick(rng, ["has been temporarily locked", "will be suspended",
                        "shows unusual sign-in activity", "needs to be re-verified"])
    subject = _pick(rng, [f"Action required: your {brand[0]} account {threat}",
                         f"Security alert for your {brand[0]} account"])
    body = (f"Dear Customer,\n\n"
            f"We're contacting you because your {brand[0]} account {threat}. "
            f"To keep your account active you must confirm your details within 24 hours.\n\n"
            f"Verify your account here: https://{bad}/login\n\n"
            f"If you do not act, access may be removed.\n\n{brand[0]} Security Team")
    header = (f"From: {brand[0]} Security <security@{bad}>\nTo: {who[1]}\n"
              f"Subject: {subject}\n\n")
    return header + body, subject


def _phish_bec_bank(rng, who) -> tuple[str, str]:
    """Business email compromise: 'our bank details changed'. Calm, no links."""
    name, _, dom = who
    boss = _pick(rng, COLLEAGUES)
    subject = _pick(rng, ["Updated remittance details", "Account update for next payment",
                         "Change to our banking details"])
    body = (f"Hi {name.split()[0]},\n\n"
            f"Please note we've changed banks. For the outstanding invoice, use our new "
            f"account details below instead of the old ones:\n\n"
            f"  BSB: 06{rng.randint(1000,9999)}  Acct: {rng.randint(10000000,99999999)}\n\n"
            f"Can you update your records and confirm once done? I'm in meetings most of "
            f"today so email is best.\n\nThanks,\n{boss}")
    # Free-webmail sender using the boss's name = the giveaway.
    bad = f"{boss.split()[0].lower()}.{boss.split()[1].lower()}{rng.randint(1,99)}@gmail.com"
    header = (f"From: {boss} <{bad}>\nReply-To: {bad}\nTo: {who[1]}\nSubject: {subject}\n\n")
    return header + body, subject


def _phish_gift_card(rng, who) -> tuple[str, str]:
    """The gift-card 'quick favour from the boss' scam."""
    name, _, _ = who
    boss = _pick(rng, COLLEAGUES)
    subject = _pick(rng, ["Quick favour", "Are you available?", "Need your help"])
    body = (f"Hi {name.split()[0]},\n\n"
            f"Are you at your desk? I need you to sort out a quick task discreetly - it's "
            f"a surprise for the team. Can you pick up a few gift cards and send me the "
            f"codes from the back? I'll reimburse you. I'm stuck in a meeting and can't "
            f"take calls, so reply by email.\n\nThanks,\n{boss}")
    bad = f"{boss.split()[0].lower()}{rng.randint(100,999)}@outlook.com"
    header = (f"From: {boss} <{bad}>\nTo: {who[1]}\nSubject: {subject}\n\n")
    return header + body, subject


def _phish_parcel(rng, who) -> tuple[str, str]:
    """Delivery-fee scam with a shortened or risky link."""
    name, _, _ = who
    link = _pick(rng, ["https://bit.ly/3" + "".join(_pick(rng, "abcdefghjkmnpqrstuvwxyz23456789") for _ in range(5)),
                      "http://swiftparcel-redelivery.top/pay"])
    subject = _pick(rng, ["Your parcel is waiting", "Delivery failed - action needed",
                         "Unpaid delivery fee"])
    body = (f"Hello,\n\nWe tried to deliver your parcel but a small redelivery fee of "
            f"$1.99 is unpaid. Please confirm and pay within 24 hours or it will be "
            f"returned.\n\nPay here: {link}\n\nSwiftParcel")
    bad = _pick(rng, ["info@swiftparcel-redelivery.top", "delivery@swift-parcel.click"])
    header = (f"From: SwiftParcel <{bad}>\nTo: {who[1]}\nSubject: {subject}\n\n")
    return header + body, subject


def _phish_reward(rng, who) -> tuple[str, str]:
    """Prize / refund lure, generic greeting."""
    name, _, _ = who
    prize = _pick(rng, ["a $500 gift card", "a tax refund of $428.50", "a reward voucher"])
    bad = _pick(rng, ["rewards@brightmart-prizes.xyz", "refund@tax-point.click"])
    subject = _pick(rng, [f"Congratulations! You've won {prize}", "You are eligible for a refund"])
    body = (f"Dear Valued Customer,\n\nCongratulations! You have been selected to receive "
            f"{prize}. To claim your reward, confirm your details now:\n"
            f"http://{bad.split('@')[1]}/claim\n\nThis offer expires today. Don't miss out!")
    header = (f"From: Rewards <{bad}>\nTo: {who[1]}\nSubject: {subject}\n\n")
    return header + body, subject


def _phish_calm_credential(rng, who) -> tuple[str, str]:
    """A quieter phishing email - the kind a cartoonish model would miss."""
    name, _, _ = who
    brand = _pick(rng, [("SignFlow", "signflow"), ("Ledgerly", "ledgerly")])
    bad = f"{brand[1]}-docs.com"
    subject = _pick(rng, [f"A document is shared with you on {brand[0]}",
                         "You have a document to review"])
    body = (f"Hi {name.split()[0]},\n\nA document has been shared with you for review. "
            f"You can open it here:\nhttps://{bad}/d/{rng.randint(10000,99999)}\n\n"
            f"You may be asked to sign in to view it.\n\n{brand[0]}")
    header = (f"From: {brand[0]} <no-reply@{bad}>\nTo: {who[1]}\nSubject: {subject}\n\n")
    return header + body, subject


def _phish_attachment(rng, who) -> tuple[str, str]:
    """Malware attachment disguised as a document."""
    name, _, _ = who
    fname = _pick(rng, ["Invoice_overdue.pdf.exe", "Statement_Oct.pdf.scr",
                       "Remittance.docx.iso", "Voicemail.htm"])
    subject = _pick(rng, ["Overdue invoice attached", "New voicemail message", "Remittance advice"])
    body = (f"Dear Customer,\n\nPlease see the attached {subject.lower()}. Open the "
            f"attachment to view the details.\n\nRegards,\nAccounts")
    bad = _pick(rng, ["accounts@invoices-secure.top", "voicemail@msg-delivery.click"])
    header = (f"From: Accounts <{bad}>\nTo: {who[1]}\nSubject: {subject}\n"
              f"Attachments: {fname}\n\n")
    return header + body, subject


# (builder, label, category, note, tags, how many variants to generate)
TEMPLATES = [
    (_legit_invoice, 0, "legitimate invoice", "", ["payment"], 16),
    (_legit_newsletter, 0, "legitimate newsletter", "", ["marketing"], 10),
    (_legit_reset, 0, "legitimate password reset", "hard: mentions password + link", ["credential"], 12),
    (_legit_overdue, 0, "legitimate overdue reminder", "hard: urgent but genuine", ["payment", "urgency"], 12),
    (_legit_internal, 0, "legitimate internal note", "", ["internal"], 12),
    (_phish_brand_credential, 1, "phishing: fake login", "", ["credential", "lookalike"], 16),
    (_phish_bec_bank, 1, "phishing: bank-change (BEC)", "hard: calm, no links", ["bec", "payment"], 12),
    (_phish_gift_card, 1, "phishing: gift-card", "", ["bec", "gift_card"], 10),
    (_phish_parcel, 1, "phishing: parcel fee", "", ["smishing", "link"], 12),
    (_phish_reward, 1, "phishing: prize/refund", "", ["reward"], 10),
    (_phish_calm_credential, 1, "phishing: quiet doc-share", "hard: low-key phishing", ["credential"], 12),
    (_phish_attachment, 1, "phishing: malware attachment", "", ["attachment"], 10),
]


def generate(seed: int = 7) -> list[Example]:
    rng = random.Random(seed)
    examples: list[Example] = []
    for index, (builder, label, category, note, tags, count) in enumerate(TEMPLATES):
        group = f"T{index:02d}"
        seen: set[str] = set()
        attempts = 0
        made = 0
        while made < count and attempts < count * 12:
            attempts += 1
            who = _pick(rng, RECIPIENTS)
            text, _ = builder(rng, who)
            if text in seen:                 # keep variants genuinely distinct
                continue
            seen.add(text)
            made += 1
            examples.append(Example(text=text, label=label, group=group,
                                    category=category, note=note, tags=list(tags)))
    rng.shuffle(examples)
    return examples


def write_jsonl(examples: list[Example], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for example in examples:
            handle.write(json.dumps(asdict(example), ensure_ascii=False) + "\n")


def load_jsonl(path: Path) -> list[Example]:
    examples = []
    with Path(path).open(encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                examples.append(Example(**json.loads(line)))
    return examples


def dataset_card(examples: list[Example]) -> str:
    phishing = sum(e.label for e in examples)
    groups = sorted({e.group for e in examples})
    lines = [
        "# WarnMail synthetic dataset", "",
        f"- Total emails: **{len(examples)}**",
        f"- Phishing: **{phishing}**  |  Legitimate: **{len(examples) - phishing}**",
        f"- Template groups: **{len(groups)}** (variants of one template share a group id)",
        "",
        "All brands, people and domains are fictional. The data is generated from "
        "templates in `training/dataset.py` and is intended only to teach the detector "
        "the *shape* of common scams. For a real project, replace it with realistic "
        "examples you have gathered and labelled yourself.", "",
        "## Why template groups matter", "",
        "Variations of one template are very similar. If some land in training and "
        "others in testing, the model is effectively tested on what it already saw, and "
        "its scores look far better than they are. The training script splits by group "
        "so a whole template stays on one side. This is the single most important habit "
        "to learn with a small dataset.", "",
        "## Categories", "",
        "| Category | Count | Label | Note |", "| --- | --- | --- | --- |",
    ]
    by_cat: dict[str, list[Example]] = {}
    for example in examples:
        by_cat.setdefault(example.category, []).append(example)
    for category, items in sorted(by_cat.items(), key=lambda kv: (-kv[1][0].label, kv[0])):
        label = "phishing" if items[0].label else "legitimate"
        lines.append(f"| {category} | {len(items)} | {label} | {items[0].note or '-'} |")
    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate WarnMail's synthetic dataset.")
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--out", type=Path, default=DATA_DIR / "dataset.jsonl")
    args = parser.parse_args()

    examples = generate(seed=args.seed)
    write_jsonl(examples, args.out)
    (DATA_DIR / "DATASET_CARD.md").write_text(dataset_card(examples), encoding="utf-8")
    phishing = sum(e.label for e in examples)
    print(f"Wrote {len(examples)} emails ({phishing} phishing, {len(examples)-phishing} legitimate) "
          f"to {args.out}")
    print(f"Dataset card: {DATA_DIR / 'DATASET_CARD.md'}")


if __name__ == "__main__":
    main()
