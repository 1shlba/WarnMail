"""Training-time code: dataset generation, model training and evaluation.

Nothing in this package is needed to *run* WarnMail (the GUI only needs the
saved model). It is kept separate so the packaged app stays small and so the
learning-oriented code is easy to find.
"""
