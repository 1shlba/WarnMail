# WarnMail learning guide

This guide is for someone new to machine learning and to Random Forests. It
explains the ideas WarnMail uses, the beginner mistakes it was built to show,
and how to take it further. It pairs with the code in `training/` and
`warnmail/model.py`.

---

## 1. The problem, in machine-learning terms

We want to sort emails into two classes: **phishing (1)** and **legitimate
(0)**. That is a *binary classification* problem. To use a model we must turn
each email into a fixed list of numbers — its **features**. WarnMail's features
are things like "how many urgent words", "does a link go to a bare IP
address", "does the sender's name match the address" (see `warnmail/features.py`).

Two approaches, combined:

- **Rules** — a human writes down known warning signs. Transparent and
  specific, but only catch what the author thought of.
- **A model** — learns patterns from labelled examples. Can catch combinations
  a human wouldn't list, but needs data and can be fooled by surface wording.

WarnMail uses both and blends them (the *hybrid* mode). The rest of this guide
is mostly about the model, because that is the part with the sharp edges.

---

## 2. What a Random Forest is

Start with one **decision tree**. It asks yes/no questions about the features —
"more than 2 urgent words?", "any disguised links?" — and each answer leads to
another question, until it reaches a leaf that says "phishing" or "legitimate".
A single tree is easy to read but tends to **overfit**: it memorises the
training data, including its noise, and does poorly on new emails.

A **Random Forest** grows many trees (WarnMail uses 200), each on a random
subset of the data and features, and averages their votes. The randomness means
the trees make *different* mistakes, and averaging cancels much of the noise out.
The result is more accurate and more stable than any single tree.

Key settings (in `training/train_model.py`, found by `GridSearchCV`):

| Setting | What it does | WarnMail's value |
| --- | --- | --- |
| `n_estimators` | number of trees | 200 |
| `max_depth` | how many questions deep a tree may go | 4 (shallow, on purpose) |
| `min_samples_leaf` | smallest group a leaf may decide on | 1 |
| `max_features` | features considered per split | `sqrt` |
| `class_weight` | counter an uneven class split | `balanced` |

A shallow `max_depth` is deliberate: with little data, deep trees just memorise.

---

## 3. The five mistakes this project is built to teach

These are the errors a first Random Forest project runs into. WarnMail either
fixes each one or shows it on purpose.

### Mistake 1 — Data leakage (the big one)

If near-identical emails appear in **both** the training set and the test set,
the model is effectively tested on what it has already seen. Its scores look
wonderful and mean nothing.

WarnMail's synthetic emails come in **template groups**: all the variations of
one template share a `group` id. Training splits **by group**, so a whole
template stays on one side. The training run prints the gap:

```
Leakage check: honest grouped f1=0.509  vs  leaky random-split f1=0.938
```

Same model, same data — the only difference is whether variants of a template
were allowed to leak across the split. The leaky number (**0.94**) is the
tempting lie; the grouped number (**0.51**) is the truth. *Always split by
whatever makes your rows similar* (sender, template, campaign, time).

### Mistake 2 — "100% accuracy!"

A first model often scores perfectly, which is a warning, not a success. Usual
causes: leakage (mistake 1), or examples so obviously different that the task is
trivial, or testing on the training data. WarnMail's synthetic phishing is made
*harder* on purpose (calm bank-change emails, genuine-but-urgent invoices) so
the honest model lands at a believable **f1 ≈ 0.64**, not 1.0.

### Mistake 3 — Dividing by zero on an email with no links

Many features are ratios ("share of links that leave the sender's site"). An
email with **no links** makes that `0/0`. Compute it directly and the app
crashes — on a real user's perfectly ordinary email. WarnMail routes every
ratio through `safe_ratio(part, whole)` which returns `0.0` when `whole` is 0.
There is a test for exactly this (`tests/test_features.py`).

### Mistake 4 — Feature order drifting between training and prediction

A Random Forest sees a list of numbers, not names. If training feeds features
in one order and the app feeds them in another, the model still returns an
answer — just a meaningless one, with **no error message**. WarnMail stores the
feature names *inside the model file* and checks them on load
(`model.check_feature_names`); a mismatch refuses to run rather than lying.
`tests/test_analyzer_and_model.py` covers this.

### Mistake 5 — Ignoring class imbalance and the wrong metric

WarnMail's dataset is 82 phishing to 62 legitimate. If one class dominated, a
lazy model could score well just by always guessing it, so we set
`class_weight="balanced"`. And **accuracy alone is misleading**: catching
phishing (recall) and not crying wolf (precision) matter differently. WarnMail
reports precision, recall and **f1** (their balance), and shows the full
confusion matrix.

---

## 4. Reading WarnMail's honest scores

From the shipped model (`python -m training.train_model`):

```
Grouped cross-validation (model alone, honest):
  precision 0.68   recall 0.61   f1 0.64   accuracy 0.61
```

What each word means, in this context:

- **Recall 0.61** — of the real phishing emails, the model (alone) caught 61%.
- **Precision 0.68** — of the emails it flagged, 68% really were phishing.
- **f1 0.64** — the balance of the two (the headline single number).

The **confusion matrix** is the clearest view (phishing = positive):

|  | model says phishing | model says legitimate |
| --- | --- | --- |
| **actually phishing** | 50 caught | 32 missed |
| **actually legitimate** | 24 false alarms | 38 cleared |

This is measured with **grouped cross-validation**: the data is split into
folds by template group, each fold is predicted by a model trained on the
others, and every email ends up scored by a model that never saw its template.
With only 12 groups, this is far more trustworthy than holding out a single
test slice (which swings wildly depending on which groups land in it).

### Why do the rules score higher than the model here?

Run `python -m training.evaluate` and the **rules** score near-perfect while
the **model alone** sits at f1 0.64. That is **not** because the rules are
better than machine learning. It is because the synthetic emails were written
from the same list of tricks the rules check for, so the rules are being tested
on exactly what they were built to catch. Real phishing uses patterns you
didn't hand-code — and that is where a model earns its place. The lesson:
**a near-perfect score on data you generated yourself proves very little.**

---

## 5. How the hybrid blends the two

In `warnmail/analyzer.py`:

```
combined = 0.6 × (model probability × 100) + 0.4 × (rule score)
```

Then **safety overrides**: 1 strong (high-severity) finding lifts the result to
at least Medium, 2 or more to High. This stops a confident-but-wrong model from
averaging away a clear sign like a disguised link or a gift-card request. The
cut-offs (35 and 65) and the weights live in `warnmail/config.py` — change them
and re-run `python -m training.evaluate` to see the effect.

---

## 6. How the model explains itself

A Random Forest can seem like a black box, but each prediction *can* be
explained. `warnmail/model.explain_prediction` follows the email down every
tree: each tree starts at a baseline (the share of phishing it trained on) and
every yes/no split nudges the probability up or down. Crediting each nudge to
the feature used there, and averaging over all trees, gives each feature's
contribution. They add up exactly to the prediction:

```
baseline + sum(feature effects) == predicted probability
```

There is a test asserting this equality to six decimal places. (This is the
"Saabas" method, the same idea as the `treeinterpreter` package.)

---

## 7. Extending WarnMail (good exercises)

1. **Add a feature** in `features.py` (e.g. "number of recipients"), retrain,
   and see if the honest f1 moves. Remember to retrain — the saved model won't
   know about a new feature, and the app will refuse to load until you do.
2. **Add realistic data.** Replace the synthetic templates in
   `training/dataset.py` with harder, more realistic examples, keeping the
   group discipline. Watch the honest score drop — that's realism, not failure.
3. **Move the threshold.** In `config.py`, try `MEDIUM_THRESHOLD = 25`. You'll
   catch more phishing (higher recall) but raise more false alarms (lower
   precision). This trade-off is the heart of detection.
4. **Try another model.** Swap `RandomForestClassifier` for
   `LogisticRegression` or `GradientBoostingClassifier` in `train_model.py` and
   compare. (The feature-name check still protects you.)
5. **Build the .exe with GitHub Actions** instead of locally, so a Windows
   runner produces it automatically on every push (see below).

---

## 8. Packaging notes (PyInstaller)

- PyInstaller bundles Python, your code and the libraries into one executable,
  and builds **for the OS it runs on** — a Windows `.exe` needs a Windows build.
- scikit-learn loads some parts dynamically, which static analysis misses, so
  `warnmail.spec` pulls in its submodules explicitly. Without that, the `.exe`
  builds fine but crashes with `ModuleNotFoundError` only when run — a classic
  trap.
- Data files (the model, the samples, the icon) must be declared in the spec's
  `datas`, and found at runtime through `config.bundle_root()`.
- To build a Windows `.exe` without a Windows PC, add a GitHub Actions workflow
  on a `windows-latest` runner that runs `pip install -r requirements.txt`,
  `pip install pyinstaller`, then `pyinstaller warnmail.spec`, and uploads
  `dist/WarnMail.exe` as an artifact.

---

## 9. Honest limitations

- Trained and tested on **synthetic** data, so the scores do not predict
  real-world performance.
- English only, and tuned to Australian small-business examples.
- Looks at text, links, sender and attachment *names* only — it does not open
  attachments, follow links, or check real email authentication (SPF/DKIM/DMARC),
  all of which a production tool would.
- The known-brand list is tiny and fictional.

Treat WarnMail as a clear, well-tested illustration of how the pieces fit
together — and as a checklist of the mistakes to avoid when you build the real
thing.
