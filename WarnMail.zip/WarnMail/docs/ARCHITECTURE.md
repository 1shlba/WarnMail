# WarnMail architecture

This document explains how the code is organised and why. If you are reading
the codebase to learn from it, start here, then read the modules in the order
below.

## Design goals

1. **One place for detection.** The app looks at an email in exactly one
   module (`signals.py`). Both the rules and the model are built on top of
   that, so they can never disagree about what is *in* the email — only about
   what it *means*.
2. **The GUI contains no logic.** Everything the interface shows can also be
   produced without a screen (the command line and the tests rely on this).
3. **Training and running are separate.** The `warnmail/` package runs the
   app; the `training/` package builds the model. The packaged .exe ships only
   the first.
4. **Honesty over headline numbers.** The evaluation is built to avoid fooling
   itself (see `docs/LEARNING_GUIDE.md`).

## The pipeline, module by module

Read the modules in this order:

### 1. `warnmail/parser.py` — raw text → `ParsedEmail`
Turns whatever the user pasted (or an `.eml` file) into a tidy structure:
sender, subject, body, links and attachments. Handles header lines, Outlook's
`text<url>` links, raw HTML, and full MIME emails. **No judgement happens
here** — it only reads.

### 2. `warnmail/domains.py` and `warnmail/indicators.py` — the knowledge
Reference data with no state:
- `domains.py`: how to find the real domain behind a link, lists of free
  webmail / shortener / risky domains, and the look-alike detector (undoing
  tricks like `harb0urline`, and measuring edit distance to real brands).
- `indicators.py`: the word lists ("lexicons") for urgency, threats,
  credential requests, gift cards, and so on, plus attachment-type lists.

### 3. `warnmail/signals.py` — `ParsedEmail` → `Signals`
The single detection step. It runs every check once and records the evidence:
which phrases appear, which links are risky and why, whether the sender's name
matches the address, which attachments are dangerous. Everything downstream
reads from the `Signals` object.

### 4a. `warnmail/features.py` — `Signals` → numbers
Turns the signals into the fixed, ordered list of numbers the model needs.
`FEATURE_NAMES` is the contract between training and prediction. Every ratio
goes through `safe_ratio` so an email with no links gives 0, not a crash.

### 4b. `warnmail/rules.py` — `Signals` → findings + score
The human-readable half. Each rule is a small function returning a `Finding`
(severity + plain-language explanation) or `None`. Points per severity add up
to a 0–100 rule score.

### 5. `warnmail/model.py` — the Random Forest
Loads and saves the model *bundle* (the fitted model plus the feature names it
was trained with and some metadata). It refuses to run if the feature list
doesn't match, which catches the most common silent ML bug. It can also
**explain** a single prediction by following it down every tree.

### 6. `warnmail/analyzer.py` — bring it together
Runs the whole pipeline and produces an `AnalysisResult` in one of three
modes: `rules`, `model`, `hybrid`. The hybrid mode blends the rule score and
the model probability, then applies **safety overrides**: one or more strong,
specific findings lift the rating so a confident model can't average them
away.

### 7. `warnmail/report.py` — the result and its text form
`AnalysisResult` is what everything receives. `to_text()` renders the report
the GUI and CLI show.

### 8. `warnmail/gui.py` / `warnmail/cli.py` — the front doors
The Tkinter window and the command-line tool. Both just call `Analyzer` and
display the result. The GUI loads the model on a background thread so the
window opens instantly.

## The training side

```
training/dataset.py    generate synthetic, labelled emails (with template groups)
training/featurise.py  email text → feature matrix (reuses the app's pipeline)
training/train_model.py tune + train + save, with a data-leakage demonstration
training/evaluate.py    compare rules vs model vs hybrid, honestly
```

`featurise.py` deliberately reuses `warnmail`'s own parser, signals and
features, so the model is always trained on exactly what the app will feed it
at runtime.

## Data flow for packaging

The model, the samples and the icon are **data files**, not code. At runtime
they are found through `config.bundle_root()`, which returns the project folder
normally and PyInstaller's unpack folder (`sys._MEIPASS`) inside the .exe. This
one indirection is what lets the same code run from source and when frozen.

## Where to change things

| You want to… | Edit… |
| --- | --- |
| Add a warning phrase | `indicators.py` |
| Add/retune a rule | `rules.py` (add to `RULES`) |
| Add a feature for the model | `features.py` (then retrain) |
| Change the Low/Med/High cut-offs or blend | `config.py` |
| Add a known brand to protect | `domains.py` (`KNOWN_BRANDS`) |
| Add training examples | `training/dataset.py` |
| Change the look of the app | `gui.py` |
