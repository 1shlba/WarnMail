"""Tests for the rule engine and the analyzer's decisions."""

from warnmail.parser import parse_email
from warnmail.signals import detect
from warnmail.rules import evaluate_rules


def findings_for(text: str):
    result = evaluate_rules(detect(parse_email(text)))
    return {f.rule_id: f for f in result.findings}, result


def test_disguised_link_is_high_severity():
    found, _ = findings_for(
        "Subject: hi\n\nlog in here www.cloudnest.com<http://cloudnest-login.top/go>")
    assert "disguised_link" in found
    assert found["disguised_link"].severity == "high"


def test_gift_card_request_flagged():
    found, _ = findings_for(
        "From: Boss <boss123@gmail.com>\nSubject: favour\n\n"
        "Can you buy some gift cards and send me the codes? I'm in a meeting.")
    assert "gift_cards" in found


def test_bank_change_flagged_high():
    found, _ = findings_for(
        "Subject: update\n\nWe have changed our bank details, please use the new account.")
    assert "bank_change" in found
    assert found["bank_change"].severity == "high"


def test_double_extension_attachment_is_high():
    found, _ = findings_for(
        "Subject: invoice\nAttachments: invoice.pdf.exe\n\nSee attached.")
    assert "attachment" in found
    assert found["attachment"].severity == "high"


def test_genuine_invoice_has_no_findings():
    found, result = findings_for(
        "From: Supplier <accounts@baysideoffice.com.au>\n"
        "To: me@firm.com\nSubject: Invoice INV-1\nAttachments: INV-1.pdf\n\n"
        "Hi, please find invoice INV-1 for $100, due in 14 days. Thanks.")
    assert result.score == 0
    assert found == {}


def test_reply_to_mismatch_detected():
    found, _ = findings_for(
        "From: Boss <boss@firm.com>\nReply-To: boss.private@gmail.com\n"
        "Subject: hi\n\nCan you help with a payment?")
    assert "reply_to" in found


def test_score_is_capped_at_100():
    _, result = findings_for(
        "From: Bank <security@harbourline-secure.top>\n"
        "Reply-To: x@gmail.com\nSubject: URGENT suspended verify\n"
        "Attachments: statement.pdf.exe\n\n"
        "Your account is suspended! Verify your identity and password now: "
        "http://203.0.113.1/login and buy gift cards. Bank details have changed.")
    assert result.score == 100
    assert result.high_count >= 2
