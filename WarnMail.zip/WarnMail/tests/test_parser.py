"""Tests for turning raw text into a structured email."""

from warnmail.parser import parse_email, extract_body_attachments


def test_pasted_headers_are_split_from_body():
    email = parse_email(
        "From: Jo Smith <jo@example.com>\n"
        "To: me@work.com\n"
        "Subject: Hello\n\n"
        "This is the body.")
    assert email.source_format == "pasted with headers"
    assert email.from_name == "Jo Smith"
    assert email.from_address == "jo@example.com"
    assert email.subject == "Hello"
    assert "This is the body." in email.body
    assert "From:" not in email.body


def test_body_only_has_no_sender():
    email = parse_email("Just some pasted text with no header lines at all.")
    assert email.source_format == "body only"
    assert not email.has_sender
    assert email.from_domain == ""


def test_outlook_style_link_keeps_visible_text_and_real_url():
    email = parse_email("Click here to verify your account "
                        "Harbourline Bank<http://203.0.113.9/login>")
    assert len(email.links) == 1
    assert email.links[0].host == "203.0.113.9"
    assert "Harbourline Bank" in email.links[0].text


def test_html_email_is_converted_and_links_found():
    email = parse_email(
        'From: x@test.com\nSubject: hi\n\n'
        '<html><body><p>Hello</p>'
        '<a href="https://evil.example/login">your bank</a></body></html>')
    assert "Hello" in email.body
    assert "<p>" not in email.body
    assert email.links[0].domain == "evil.example"
    assert email.links[0].text == "your bank"


def test_mime_email_file_with_attachment():
    raw = ("MIME-Version: 1.0\n"
           "From: Accounts <a@firm.com>\n"
           "To: b@firm.com\n"
           "Subject: Invoice\n"
           'Content-Type: multipart/mixed; boundary="X"\n\n'
           "--X\nContent-Type: text/plain\n\nPlease pay the invoice.\n"
           "--X\nContent-Type: application/octet-stream\n"
           'Content-Disposition: attachment; filename="invoice.pdf.exe"\n\n'
           "junk\n--X--\n")
    email = parse_email(raw)
    assert email.source_format == "email file (MIME)"
    assert email.subject == "Invoice"
    assert "invoice.pdf.exe" in email.attachments


def test_double_extension_attachment_detected_in_body():
    assert "Statement.pdf.exe" in extract_body_attachments("See Statement.pdf.exe attached")


def test_plain_domain_is_not_mistaken_for_attachment():
    # "example.com" ends in a known-looking suffix but is not a file.
    assert extract_body_attachments("visit example.com for details") == []


def test_curly_apostrophes_are_normalised():
    email = parse_email("Subject: hi\n\nWe’ve changed our details")
    assert "We've changed" in email.body
