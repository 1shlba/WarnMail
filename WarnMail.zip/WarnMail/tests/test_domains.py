"""Tests for the domain helpers and look-alike detection."""

import pytest

from warnmail import domains


@pytest.mark.parametrize("host, expected", [
    ("www.harbourlinebank.com.au", "harbourlinebank.com.au"),
    ("mail.cloudnest.com", "cloudnest.com"),
    ("harbourlinebank.com.au.secure-login.top", "secure-login.top"),
    ("203.0.113.7", "203.0.113.7"),
])
def test_registered_domain(host, expected):
    assert domains.registered_domain(host) == expected


def test_ip_address_detection():
    assert domains.is_ip_address("203.0.113.7")
    assert not domains.is_ip_address("example.com")


def test_free_webmail_recognised():
    assert domains.is_free_webmail("gmail.com")
    assert not domains.is_free_webmail("harbourlinebank.com.au")


def test_edit_distance():
    assert domains.edit_distance("cloudnest", "cloudnest") == 0
    assert domains.edit_distance("cloudnest", "cloudnests") == 1
    assert domains.edit_distance("paypal", "paypa1") == 1


def test_lookalike_detected_for_brand_token():
    protected = domains.protected_names()
    brand = domains.find_lookalike("harbourline-secure.top", protected)
    assert brand is not None and "Harbourline" in brand.label


def test_genuine_domain_is_not_a_lookalike():
    protected = domains.protected_names()
    assert domains.find_lookalike("harbourlinebank.com.au", protected) is None


def test_confusable_characters_are_caught():
    protected = domains.protected_names()
    # "harb0urline" with a zero should still match Harbourline.
    brand = domains.find_lookalike("harb0urline-login.xyz", protected)
    assert brand is not None


def test_recipient_domain_added_as_protected():
    protected = domains.protected_names("priya@riverbendaccounting.com.au")
    labels = [p.label for p in protected]
    assert "your organisation" in labels
