"""Tests for the analyzer, the model bundle and the explanation maths.

These use the trained model if it is present; where a test needs the model
it is skipped (not failed) when no model has been built yet, so the suite
still runs on a fresh checkout before training.
"""

import numpy as np
import pytest

from warnmail import config
from warnmail.analyzer import Analyzer
from warnmail.features import FEATURE_NAMES, extract_features
from warnmail.model import (ModelError, check_feature_names, explain_prediction,
                            load_bundle, predict_probability)
from warnmail.parser import parse_email
from warnmail.signals import detect

HAS_MODEL = config.MODEL_PATH.exists()
model_required = pytest.mark.skipif(not HAS_MODEL, reason="no trained model yet")


def test_rules_mode_needs_no_model():
    # require_model=False means the app still works with no model file.
    analyzer = Analyzer(model_path=config.MODEL_PATH)
    result = analyzer.analyze(
        "From: Bank <security@harbourline-secure.top>\nSubject: URGENT\n\n"
        "Verify now: http://203.0.113.1/login", mode="rules")
    assert result.level in ("Medium", "High")
    assert result.mode == "rules"


def test_strong_signs_force_high_in_rules_mode():
    analyzer = Analyzer()
    result = analyzer.analyze(
        "From: Boss <boss@gmail.com>\nSubject: favour\n\n"
        "Buy gift cards and send the codes. Also our bank details have changed.",
        mode="rules")
    # Two high-severity findings must force a High rating via the override.
    assert result.level == "High"


def test_unknown_mode_raises():
    with pytest.raises(ValueError):
        Analyzer().analyze("hi", mode="nonsense")


@model_required
def test_model_loads_with_matching_features():
    bundle = load_bundle(config.MODEL_PATH)
    assert bundle.feature_names == FEATURE_NAMES
    check_feature_names(bundle)                       # must not raise


@model_required
def test_feature_mismatch_is_rejected():
    bundle = load_bundle(config.MODEL_PATH)
    bundle.feature_names = bundle.feature_names[:-1] + ["something_else"]
    with pytest.raises(ModelError):
        check_feature_names(bundle)


@model_required
def test_probability_in_range():
    bundle = load_bundle(config.MODEL_PATH)
    features = extract_features(detect(parse_email("Subject: hi\n\nhello")))
    p = predict_probability(bundle, features)
    assert 0.0 <= p <= 1.0


@model_required
def test_explanation_adds_up_to_probability():
    # baseline + sum of every feature's effect should equal the model's
    # predicted probability (this is what makes the explanation trustworthy).
    bundle = load_bundle(config.MODEL_PATH)
    features = extract_features(detect(parse_email(
        "From: Bank <security@harbourline-secure.top>\nSubject: URGENT verify\n\n"
        "Your account is suspended. http://203.0.113.1/login")))
    probability = predict_probability(bundle, features)
    explanation = explain_prediction(bundle, features, top=None)   # every feature
    total = explanation.baseline + sum(c.effect for c in explanation.contributions)
    assert total == pytest.approx(probability, abs=1e-6)


@model_required
def test_clear_phishing_is_high_in_every_mode():
    analyzer = Analyzer()
    phishing = ("From: Harbourline Bank <security@harbourline-secure.top>\n"
                "Reply-To: x@gmail.com\nSubject: URGENT account suspended\n\n"
                "Verify your identity now or lose access: "
                "Harbourline Bank<http://203.0.113.45/login>")
    for mode in ("rules", "model", "hybrid"):
        result = analyzer.analyze(phishing, mode=mode)
        assert result.is_flagged, f"{mode} did not flag obvious phishing"


def test_trusted_source_caps_an_otherwise_medium_email():
    # Rules mode is deterministic (no model). This trusted-sender email trips
    # two medium findings (would be Medium on its own), but every link stays on
    # google.com and there is no high-severity flag, so trust caps it at Low.
    analyzer = Analyzer()
    email = ("From: Google Docs <comments-noreply@docs.google.com>\n"
             "To: sam@example.com\nSubject: Action required: verify to keep access\n\n"
             "Please verify your account and sign in to confirm your details. This is "
             "urgent - your access will be suspended today.\n"
             "Open in Docs: https://docs.google.com/document/d/1A2b3C/edit")
    without_trust = analyzer.analyze(email.replace("docs.google.com/document", "docs.g00gle-share.top/document")
                                          .replace("comments-noreply@docs.google.com", "noreply@docs.g00gle-share.top"),
                                     mode="rules")
    trusted = analyzer.analyze(email, mode="rules")
    assert without_trust.is_flagged              # same wording, untrusted domain -> flagged
    assert trusted.level == "Low"                # trusted sender + trusted link -> capped
    assert any("trusted service" in o for o in trusted.overrides)


def test_spoofed_google_sender_is_not_trusted():
    # From claims google.com, but the link goes to an attacker's site. Trust
    # must be refused - this is the spoofing case the gate is designed for.
    analyzer = Analyzer()
    email = ("From: Google Security <no-reply@google.com>\n"
             "To: sam@example.com\nSubject: Unusual sign-in - verify now\n\n"
             "Confirm your identity now: "
             "Google<http://google-account-verify.top/login>")
    result = analyzer.analyze(email, mode="hybrid")
    assert result.is_flagged, "spoofed sender with an attacker link must not be trusted"


def test_trusted_sender_with_high_finding_is_not_trusted():
    # Even a real trusted domain is not trusted if a strong red flag is present.
    analyzer = Analyzer()
    email = ("From: Accounts <billing@google.com>\n"
             "To: sam@example.com\nSubject: invoice\nAttachments: invoice.pdf.exe\n\n"
             "Please open the attached invoice.")
    result = analyzer.analyze(email, mode="hybrid")
    assert result.is_flagged, "a risky attachment must override trusted-sender status"


@model_required
def test_clear_legitimate_is_low_in_hybrid():
    analyzer = Analyzer()
    legit = ("From: Bayside Office <accounts@baysideoffice.com.au>\n"
             "To: me@firm.com\nSubject: Invoice INV-1\nAttachments: INV-1.pdf\n\n"
             "Hi, please find invoice INV-1 for $100, due in 14 days. Thanks, Mel.")
    result = analyzer.analyze(legit, mode="hybrid")
    assert result.level == "Low"
