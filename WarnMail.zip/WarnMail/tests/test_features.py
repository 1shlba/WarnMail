"""Tests for feature extraction - especially the beginner traps."""

from warnmail.features import FEATURE_NAMES, extract_features, to_vector
from warnmail.parser import parse_email
from warnmail.signals import detect


def features_for(text: str):
    return extract_features(detect(parse_email(text)))


def test_feature_order_is_stable_and_complete():
    f = features_for("Subject: hi\n\nhello")
    assert list(f.keys()) == FEATURE_NAMES
    assert len(FEATURE_NAMES) == len(set(FEATURE_NAMES))        # no duplicates


def test_email_with_no_links_gives_zero_not_crash():
    # The classic divide-by-zero trap: a ratio over zero links.
    f = features_for("Subject: hello\n\nNo links here at all.")
    assert f["link_count"] == 0
    assert f["offsite_link_ratio"] == 0.0                       # not NaN, not an error


def test_empty_email_is_handled():
    f = features_for("")
    assert f["body_words"] == 0
    assert f["shouting_ratio"] == 0.0


def test_to_vector_follows_requested_order():
    f = features_for("Subject: hi\n\nhello")
    reordered = list(reversed(FEATURE_NAMES))
    vector = to_vector(f, reordered)
    assert vector[0] == f[reordered[0]]


def test_phishing_email_lights_up_expected_features():
    f = features_for(
        "From: Bank <security@harbourline-secure.top>\n"
        "Subject: URGENT verify your account\n\n"
        "Your account is suspended. Verify now: http://203.0.113.9/login")
    assert f["urgency_phrases"] >= 1
    assert f["threat_phrases"] >= 1
    assert f["ip_links"] == 1
    assert f["lookalike_domains"] >= 1
    assert f["has_sender"] == 1


def test_all_feature_values_are_floats():
    f = features_for("Subject: hi\n\nhello world")
    assert all(isinstance(v, float) for v in f.values())
